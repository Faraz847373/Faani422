# Scholarship Application Website

A complete, beginner-friendly, and production-ready Scholarship Application Website built with PHP, MySQL, and Vanilla JavaScript. This project allows students to apply for scholarships online and administrators to manage applications through a secure admin panel.

---

## Features

### Student-Facing Features
- **Home Page**: Introduction, eligibility, important dates, and a call-to-action.
- **Application Form**: A detailed form for personal, academic, and financial information.
- **Secure File Uploads**: Upload CNIC and educational documents (PDF, JPG, PNG) with validation.
- **Client-Side Validation**: Real-time form validation using Vanilla JavaScript.
- **Success Page**: Confirmation message with a unique application reference number.
- **Status Check**: Applicants can track their application status using their CNIC or reference number.

### Admin Panel Features
- **Secure Login**: Session-based authentication for administrators.
- **Dashboard**: At-a-glance statistics of total, pending, approved, and rejected applications.
- **Application Management**: View, filter, and search all applications.
- **Detailed View**: Review complete application details, including uploaded documents.
- **Status Updates**: Approve, reject, or mark applications as "under review".
- **Admin Notes**: Add internal notes to applications.
- **Status History**: Audit trail for all status changes.
- **Responsive Design**: The admin panel is usable on both desktop and mobile devices.

---

## Tech Stack

- **Frontend**: HTML5, Clean CSS (Tailwind-like utility classes), Vanilla JavaScript
- **Backend**: PHP 8.x (Procedural with a simple class-based structure)
- **Database**: MySQL / MariaDB
- **Server**: Nginx + PHP-FPM (also compatible with Apache)

---

## Folder Structure

The project follows a clean and organized folder structure to separate concerns.

```
/scholarship-website
├── admin/                  # Admin panel files
│   ├── includes/           # Admin-specific includes (auth, header, footer)
│   ├── index.php           # Admin dashboard
│   ├── login.php           # Admin login page
│   ├── applications.php    # List all applications
│   └── ...
├── assets/                 # Shared CSS, JS, and images
│   ├── css/style.css
│   └── js/main.js
├── database/               # Database schema file
│   └── schema.sql
├── includes/               # Core PHP files (config, database, functions)
│   ├── config.php          # Main configuration
│   ├── database.php        # Database connection class
│   └── functions.php       # Helper functions
├── logs/                   # Error logs directory (must be writable)
├── public/                 # Public-facing files (document root)
│   ├── index.php           # Home page
│   ├── apply.php           # Application form
│   └── ...
├── uploads/                # Directory for user-uploaded files
│   └── applications/       # Application documents
├── .htaccess               # Apache security and rewrite rules
├── index.php               # Root redirect to /public
└── README.md               # This file
```

---

## Setup and Installation

Follow these steps to set up the project on your local machine or server.

### 1. Database Setup

1.  **Create a Database**: Using a tool like phpMyAdmin or the MySQL command line, create a new database.

    ```sql
    CREATE DATABASE scholarship_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    ```

2.  **Import Schema**: Import the `database/schema.sql` file into your newly created database. This will create the necessary tables (`applications`, `admin_users`, `application_status_history`) and insert a default admin user.

    ```bash
    mysql -u your_username -p scholarship_db < database/schema.sql
    ```

3.  **Default Admin Credentials**:
    - **Username**: `admin`
    - **Password**: `Admin@123`

    > **IMPORTANT**: Change the default password immediately after your first login for security reasons.

### 2. Configuration

1.  **Edit `config.php`**: Open the `includes/config.php` file.

2.  **Update Database Credentials**: Modify the following lines with your database details.

    ```php
    define(\'DB_HOST\', \'localhost\');
    define(\'DB_NAME\', \'scholarship_db\');
    define(\'DB_USER\', \'your_db_user\');
    define(\'DB_PASS\', \'your_db_password\');
    ```

3.  **Update Site URL**: Change the `SITE_URL` to your domain or local server address. For a local setup, this might be `http://localhost/scholarship-website`.

    ```php
    define(\'SITE_URL\', \'http://your-domain.com\');
    ```

### 3. File Permissions

Ensure that the web server has write permissions for the following directories:

-   `/uploads/applications`
-   `/logs`

You can set the permissions using the following command on a Linux server:

```bash
# Set ownership to the web server user (e.g., www-data for Nginx/Apache on Debian/Ubuntu)
sudo chown -R www-data:www-data /path/to/scholarship-website

# Set correct permissions for directories
sudo find /path/to/scholarship-website -type d -exec chmod 755 {} \;

# Set correct permissions for files
sudo find /path/to/scholarship-website -type f -exec chmod 644 {} \;

# Grant write access to specific directories
sudo chmod -R 775 /path/to/scholarship-website/uploads
sudo chmod -R 775 /path/to/scholarship-website/logs
```

---

## Deployment on Nginx

For production, it is highly recommended to use Nginx and configure the document root to point directly to the `/public` directory. This prevents direct web access to sensitive files.

### Nginx Server Block Configuration

Below is a sample Nginx server block configuration. Create a new file in `/etc/nginx/sites-available/your-domain.com` and add the following content. Remember to replace `your-domain.com` and paths accordingly.

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name your-domain.com www.your-domain.com;
    root /var/www/scholarship-website/public;
    index index.php index.html;

    # Redirect www to non-www (optional)
    if ($host = www.your-domain.com) {
        return 301 http://your-domain.com$request_uri;
    }

    # For Let\'s Encrypt verification
    location ~ /.well-known/acme-challenge {
        allow all;
    }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    # Process PHP files
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        # Use the appropriate PHP-FPM socket
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock; # Adjust PHP version
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Deny access to sensitive files
    location ~ /\.ht {
        deny all;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Logging
    access_log /var/log/nginx/your-domain.com.access.log;
    error_log /var/log/nginx/your-domain.com.error.log;
}
```

### Enable the Site and Secure with SSL

1.  **Enable the new site**:

    ```bash
    sudo ln -s /etc/nginx/sites-available/your-domain.com /etc/nginx/sites-enabled/
    sudo nginx -t # Test configuration
    sudo systemctl restart nginx
    ```

2.  **Install SSL with Let's Encrypt**:

    ```bash
    sudo apt install certbot python3-certbot-nginx
    sudo certbot --nginx -d your-domain.com -d www.your-domain.com
    ```

    Certbot will automatically update your Nginx configuration to use HTTPS.

---

## Security Best Practices

-   **Change Default Admin Password**: Immediately after setup, log in and change the default admin password.
-   **Use HTTPS**: Always deploy with an SSL certificate (Let's Encrypt is free).
-   **Secure `config.php`**: In a production environment, consider moving `config.php` outside the web root directory and updating the include paths in `database.php` and `functions.php`.
-   **Disable Error Display**: In `includes/config.php`, ensure error display is turned off for production.
-   **Regular Backups**: Regularly back up your database and the `uploads` directory.
-   **Review Permissions**: Ensure file permissions are set correctly to prevent unauthorized access or modification.

---

This project is provided as a starting point. Feel free to customize and extend it to meet your specific needs.
