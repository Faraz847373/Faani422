<?php
/**
 * ============================================================
 * Admin Dashboard
 * ============================================================
 * 
 * Main dashboard showing application statistics and recent
 * applications overview.
 */

// Page metadata
$pageTitle = 'Dashboard';

// Include header (handles authentication)
require_once __DIR__ . '/includes/header.php';

// Get statistics
$db = db();

// Total applications
$totalApplications = $db->count("SELECT COUNT(*) FROM applications");

// Applications by status
$pendingCount = $db->count("SELECT COUNT(*) FROM applications WHERE status = 'pending'");
$underReviewCount = $db->count("SELECT COUNT(*) FROM applications WHERE status = 'under_review'");
$approvedCount = $db->count("SELECT COUNT(*) FROM applications WHERE status = 'approved'");
$rejectedCount = $db->count("SELECT COUNT(*) FROM applications WHERE status = 'rejected'");

// Recent applications (last 10)
$recentApplications = $db->fetchAll(
    "SELECT id, reference_number, full_name, cnic, qualification, status, created_at 
     FROM applications 
     ORDER BY created_at DESC 
     LIMIT 10"
);

// Applications this month
$thisMonthCount = $db->count(
    "SELECT COUNT(*) FROM applications WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())"
);

// Applications this week
$thisWeekCount = $db->count(
    "SELECT COUNT(*) FROM applications WHERE created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)"
);
?>

<!-- Page Header -->
<div class="page-header">
    <h1 class="page-title">Dashboard</h1>
    <p class="text-gray-600">Welcome to the Scholarship Application Management System</p>
</div>

<!-- Statistics Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-8">
    <!-- Total Applications -->
    <div class="stat-card">
        <div class="flex items-center justify-between">
            <div>
                <p class="stat-label">Total Applications</p>
                <p class="stat-value"><?php echo number_format($totalApplications); ?></p>
            </div>
            <div class="text-4xl opacity-20">📋</div>
        </div>
        <div class="mt-2 text-sm text-gray-500">
            <?php echo number_format($thisMonthCount); ?> this month
        </div>
    </div>
    
    <!-- Pending -->
    <div class="stat-card" style="border-left: 4px solid #f59e0b;">
        <div class="flex items-center justify-between">
            <div>
                <p class="stat-label">Pending Review</p>
                <p class="stat-value text-warning"><?php echo number_format($pendingCount); ?></p>
            </div>
            <div class="text-4xl opacity-20">⏳</div>
        </div>
        <a href="applications.php?status=pending" class="mt-2 text-sm text-primary-600 hover:underline">
            View all →
        </a>
    </div>
    
    <!-- Approved -->
    <div class="stat-card" style="border-left: 4px solid #10b981;">
        <div class="flex items-center justify-between">
            <div>
                <p class="stat-label">Approved</p>
                <p class="stat-value text-success"><?php echo number_format($approvedCount); ?></p>
            </div>
            <div class="text-4xl opacity-20">✅</div>
        </div>
        <a href="applications.php?status=approved" class="mt-2 text-sm text-primary-600 hover:underline">
            View all →
        </a>
    </div>
    
    <!-- Rejected -->
    <div class="stat-card" style="border-left: 4px solid #ef4444;">
        <div class="flex items-center justify-between">
            <div>
                <p class="stat-label">Rejected</p>
                <p class="stat-value text-error"><?php echo number_format($rejectedCount); ?></p>
            </div>
            <div class="text-4xl opacity-20">❌</div>
        </div>
        <a href="applications.php?status=rejected" class="mt-2 text-sm text-primary-600 hover:underline">
            View all →
        </a>
    </div>
</div>

<!-- Quick Stats Row -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
    <!-- Status Distribution -->
    <div class="card">
        <h3 class="text-lg font-semibold mb-4">Application Status Distribution</h3>
        <div class="space-y-4">
            <?php 
            $statuses = [
                ['label' => 'Pending', 'count' => $pendingCount, 'color' => '#f59e0b'],
                ['label' => 'Under Review', 'count' => $underReviewCount, 'color' => '#3b82f6'],
                ['label' => 'Approved', 'count' => $approvedCount, 'color' => '#10b981'],
                ['label' => 'Rejected', 'count' => $rejectedCount, 'color' => '#ef4444']
            ];
            
            foreach ($statuses as $status):
                $percentage = $totalApplications > 0 ? ($status['count'] / $totalApplications) * 100 : 0;
            ?>
            <div>
                <div class="flex justify-between text-sm mb-1">
                    <span><?php echo $status['label']; ?></span>
                    <span><?php echo $status['count']; ?> (<?php echo number_format($percentage, 1); ?>%)</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="h-2 rounded-full" style="width: <?php echo $percentage; ?>%; background-color: <?php echo $status['color']; ?>;"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="card">
        <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
        <div class="grid grid-cols-2 gap-4">
            <a href="applications.php" class="p-4 bg-gray-50 rounded-lg text-center hover:bg-gray-100 transition">
                <div class="text-2xl mb-2">📋</div>
                <div class="font-medium">All Applications</div>
            </a>
            <a href="applications.php?status=pending" class="p-4 bg-yellow-50 rounded-lg text-center hover:bg-yellow-100 transition">
                <div class="text-2xl mb-2">⏳</div>
                <div class="font-medium">Review Pending</div>
            </a>
            <a href="applications.php?export=csv" class="p-4 bg-green-50 rounded-lg text-center hover:bg-green-100 transition">
                <div class="text-2xl mb-2">📥</div>
                <div class="font-medium">Export Data</div>
            </a>
            <a href="profile.php" class="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition">
                <div class="text-2xl mb-2">⚙️</div>
                <div class="font-medium">Settings</div>
            </a>
        </div>
    </div>
</div>

<!-- Recent Applications -->
<div class="card">
    <div class="flex justify-between items-center mb-4">
        <h3 class="text-lg font-semibold">Recent Applications</h3>
        <a href="applications.php" class="btn btn-sm btn-secondary">View All</a>
    </div>
    
    <?php if (empty($recentApplications)): ?>
    <div class="text-center py-8 text-gray-500">
        <div class="text-4xl mb-2">📭</div>
        <p>No applications yet</p>
    </div>
    <?php else: ?>
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Applicant</th>
                    <th>CNIC</th>
                    <th>Qualification</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentApplications as $app): ?>
                <tr>
                    <td>
                        <span class="font-mono text-sm"><?php echo htmlspecialchars($app['reference_number']); ?></span>
                    </td>
                    <td>
                        <strong><?php echo htmlspecialchars($app['full_name']); ?></strong>
                    </td>
                    <td><?php echo htmlspecialchars($app['cnic']); ?></td>
                    <td><?php echo htmlspecialchars($app['qualification']); ?></td>
                    <td>
                        <span class="badge badge-<?php echo $app['status']; ?>">
                            <?php echo getStatusLabel($app['status']); ?>
                        </span>
                    </td>
                    <td class="text-sm text-gray-500">
                        <?php echo formatDate($app['created_at'], 'M d, Y'); ?>
                    </td>
                    <td>
                        <a href="view.php?id=<?php echo $app['id']; ?>" class="btn btn-sm btn-primary">
                            View
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.space-y-4 > * + * {
    margin-top: 1rem;
}
</style>

<?php
// Include footer
require_once __DIR__ . '/includes/footer.php';
?>
