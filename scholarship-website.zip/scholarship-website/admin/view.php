<?php
/**
 * ============================================================
 * Admin Application View/Detail Page
 * ============================================================
 * 
 * Displays detailed information about a single application
 * with ability to update status and add notes.
 */

// Page metadata
$pageTitle = 'View Application';

// Include header (handles authentication)
require_once __DIR__ . '/includes/header.php';

// Get application ID
$applicationId = intval($_GET['id'] ?? 0);

if (!$applicationId) {
    setFlashMessage('error', 'Invalid application ID.');
    redirect('applications.php');
}

// Get application details
$db = db();
$application = $db->fetchOne(
    "SELECT * FROM applications WHERE id = :id",
    ['id' => $applicationId]
);

if (!$application) {
    setFlashMessage('error', 'Application not found.');
    redirect('applications.php');
}

// Handle status update
if (isPost() && isset($_POST['action'])) {
    if (!validateCSRFToken()) {
        setFlashMessage('error', 'Invalid request. Please try again.');
        redirect('view.php?id=' . $applicationId);
    }
    
    $action = $_POST['action'];
    
    if ($action === 'update_status') {
        $newStatus = sanitizeString($_POST['status'] ?? '');
        $adminNotes = sanitizeString($_POST['admin_notes'] ?? '');
        
        if (in_array($newStatus, ['pending', 'under_review', 'approved', 'rejected'])) {
            // Record status change in history
            $db->insert('application_status_history', [
                'application_id' => $applicationId,
                'old_status' => $application['status'],
                'new_status' => $newStatus,
                'changed_by' => $_SESSION['admin_id'],
                'notes' => $adminNotes
            ]);
            
            // Update application
            $db->update('applications', 
                [
                    'status' => $newStatus,
                    'admin_notes' => $adminNotes
                ],
                'id = :id',
                ['id' => $applicationId]
            );
            
            setFlashMessage('success', 'Application status updated to ' . getStatusLabel($newStatus));
            redirect('view.php?id=' . $applicationId);
        }
    } elseif ($action === 'delete') {
        // Delete uploaded files
        if ($application['cnic_document'] && file_exists(__DIR__ . '/../' . $application['cnic_document'])) {
            unlink(__DIR__ . '/../' . $application['cnic_document']);
        }
        if ($application['educational_document'] && file_exists(__DIR__ . '/../' . $application['educational_document'])) {
            unlink(__DIR__ . '/../' . $application['educational_document']);
        }
        
        // Delete application
        $db->query("DELETE FROM applications WHERE id = :id", ['id' => $applicationId]);
        
        setFlashMessage('success', 'Application deleted successfully.');
        redirect('applications.php');
    }
}

// Get status history
$statusHistory = $db->fetchAll(
    "SELECT h.*, a.username as admin_username, a.full_name as admin_name 
     FROM application_status_history h 
     LEFT JOIN admin_users a ON h.changed_by = a.id 
     WHERE h.application_id = :id 
     ORDER BY h.changed_at DESC",
    ['id' => $applicationId]
);
?>

<!-- Page Header -->
<div class="page-header flex justify-between items-center">
    <div>
        <h1 class="page-title">Application Details</h1>
        <p class="text-gray-600">
            Reference: <span class="font-mono"><?php echo htmlspecialchars($application['reference_number']); ?></span>
        </p>
    </div>
    <div class="flex gap-2">
        <a href="applications.php" class="btn btn-secondary">
            ← Back to List
        </a>
        <button onclick="window.print()" class="btn btn-secondary">
            🖨️ Print
        </button>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Main Content -->
    <div class="lg:col-span-2 space-y-6">
        <!-- Personal Information -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Personal Information</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="text-sm text-gray-500">Full Name</label>
                    <p class="font-medium"><?php echo htmlspecialchars($application['full_name']); ?></p>
                </div>
                <div>
                    <label class="text-sm text-gray-500">Father's Name</label>
                    <p class="font-medium"><?php echo htmlspecialchars($application['father_name']); ?></p>
                </div>
                <div>
                    <label class="text-sm text-gray-500">CNIC</label>
                    <p class="font-medium font-mono"><?php echo htmlspecialchars($application['cnic']); ?></p>
                </div>
                <div>
                    <label class="text-sm text-gray-500">Email</label>
                    <p class="font-medium">
                        <a href="mailto:<?php echo htmlspecialchars($application['email']); ?>" class="text-primary-600">
                            <?php echo htmlspecialchars($application['email']); ?>
                        </a>
                    </p>
                </div>
                <div>
                    <label class="text-sm text-gray-500">Phone</label>
                    <p class="font-medium">
                        <a href="tel:<?php echo htmlspecialchars($application['phone']); ?>" class="text-primary-600">
                            <?php echo htmlspecialchars($application['phone']); ?>
                        </a>
                    </p>
                </div>
            </div>
        </div>
        
        <!-- Academic & Financial Information -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Academic & Financial Information</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="text-sm text-gray-500">Qualification</label>
                    <p class="font-medium"><?php echo htmlspecialchars($application['qualification']); ?></p>
                </div>
                <div>
                    <label class="text-sm text-gray-500">Monthly Family Income</label>
                    <p class="font-medium"><?php echo formatCurrency($application['monthly_income']); ?></p>
                </div>
                <div class="md:col-span-2">
                    <label class="text-sm text-gray-500">Address</label>
                    <p class="font-medium"><?php echo nl2br(htmlspecialchars($application['address'])); ?></p>
                </div>
            </div>
        </div>
        
        <!-- Uploaded Documents -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Uploaded Documents</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- CNIC Document -->
                <div class="p-4 bg-gray-50 rounded-lg">
                    <label class="text-sm text-gray-500 block mb-2">CNIC Document</label>
                    <?php if ($application['cnic_document']): ?>
                    <div class="flex items-center gap-3">
                        <span class="text-2xl"><?php echo getFileIcon($application['cnic_document']); ?></span>
                        <div class="flex-1">
                            <p class="text-sm font-medium truncate">
                                <?php echo basename($application['cnic_document']); ?>
                            </p>
                            <a href="<?php echo SITE_URL . '/' . $application['cnic_document']; ?>" 
                               target="_blank" 
                               class="text-sm text-primary-600 hover:underline">
                                View Document →
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <p class="text-gray-500">No document uploaded</p>
                    <?php endif; ?>
                </div>
                
                <!-- Educational Document -->
                <div class="p-4 bg-gray-50 rounded-lg">
                    <label class="text-sm text-gray-500 block mb-2">Educational Document</label>
                    <?php if ($application['educational_document']): ?>
                    <div class="flex items-center gap-3">
                        <span class="text-2xl"><?php echo getFileIcon($application['educational_document']); ?></span>
                        <div class="flex-1">
                            <p class="text-sm font-medium truncate">
                                <?php echo basename($application['educational_document']); ?>
                            </p>
                            <a href="<?php echo SITE_URL . '/' . $application['educational_document']; ?>" 
                               target="_blank" 
                               class="text-sm text-primary-600 hover:underline">
                                View Document →
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <p class="text-gray-500">No document uploaded</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Status History -->
        <?php if (!empty($statusHistory)): ?>
        <div class="card">
            <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Status History</h3>
            <div class="space-y-4">
                <?php foreach ($statusHistory as $history): ?>
                <div class="flex gap-4 p-3 bg-gray-50 rounded-lg">
                    <div class="flex-shrink-0">
                        <span class="badge badge-<?php echo $history['new_status']; ?>">
                            <?php echo getStatusLabel($history['new_status']); ?>
                        </span>
                    </div>
                    <div class="flex-1">
                        <p class="text-sm">
                            Changed from <strong><?php echo getStatusLabel($history['old_status'] ?? 'new'); ?></strong>
                            to <strong><?php echo getStatusLabel($history['new_status']); ?></strong>
                        </p>
                        <?php if ($history['notes']): ?>
                        <p class="text-sm text-gray-600 mt-1">
                            Note: <?php echo htmlspecialchars($history['notes']); ?>
                        </p>
                        <?php endif; ?>
                        <p class="text-xs text-gray-500 mt-1">
                            By <?php echo htmlspecialchars($history['admin_name'] ?? 'System'); ?> 
                            on <?php echo formatDate($history['changed_at']); ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Sidebar -->
    <div class="space-y-6">
        <!-- Status Card -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4">Current Status</h3>
            <div class="text-center mb-4">
                <div class="status-indicator <?php echo $application['status']; ?> mx-auto mb-2" style="width: 80px; height: 80px;">
                    <?php
                    $statusIcons = [
                        'pending' => '⏳',
                        'under_review' => '🔍',
                        'approved' => '✅',
                        'rejected' => '❌'
                    ];
                    echo $statusIcons[$application['status']] ?? '❓';
                    ?>
                </div>
                <span class="badge badge-<?php echo $application['status']; ?> text-base px-4 py-2">
                    <?php echo getStatusLabel($application['status']); ?>
                </span>
            </div>
            
            <!-- Update Status Form -->
            <form method="POST" action="view.php?id=<?php echo $applicationId; ?>">
                <?php echo csrfField(); ?>
                <input type="hidden" name="action" value="update_status">
                
                <div class="form-group">
                    <label class="form-label">Change Status</label>
                    <select name="status" class="form-select">
                        <option value="pending" <?php echo $application['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="under_review" <?php echo $application['status'] === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                        <option value="approved" <?php echo $application['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $application['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Admin Notes</label>
                    <textarea name="admin_notes" 
                              class="form-textarea" 
                              rows="3"
                              placeholder="Add notes (visible to applicant if rejected)"><?php echo htmlspecialchars($application['admin_notes'] ?? ''); ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    Update Status
                </button>
            </form>
        </div>
        
        <!-- Application Info -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4">Application Info</h3>
            <div class="space-y-3 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-500">Reference</span>
                    <span class="font-mono"><?php echo htmlspecialchars($application['reference_number']); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Submitted</span>
                    <span><?php echo formatDate($application['created_at']); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Last Updated</span>
                    <span><?php echo formatDate($application['updated_at']); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Application ID</span>
                    <span>#<?php echo $application['id']; ?></span>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="card">
            <h3 class="text-lg font-semibold mb-4">Quick Actions</h3>
            <div class="space-y-2">
                <a href="mailto:<?php echo htmlspecialchars($application['email']); ?>?subject=Regarding Your Scholarship Application (<?php echo $application['reference_number']; ?>)" 
                   class="btn btn-secondary btn-block">
                    📧 Email Applicant
                </a>
                <button onclick="window.print()" class="btn btn-secondary btn-block">
                    🖨️ Print Application
                </button>
                <form method="POST" 
                      action="view.php?id=<?php echo $applicationId; ?>" 
                      onsubmit="return confirm('Are you sure you want to delete this application? This action cannot be undone.');">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="action" value="delete">
                    <button type="submit" class="btn btn-danger btn-block">
                        🗑️ Delete Application
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.space-y-6 > * + * {
    margin-top: 1.5rem;
}

.space-y-4 > * + * {
    margin-top: 1rem;
}

.space-y-3 > * + * {
    margin-top: 0.75rem;
}

.space-y-2 > * + * {
    margin-top: 0.5rem;
}

.lg\:col-span-2 {
    grid-column: span 2;
}

@media (max-width: 1024px) {
    .lg\:col-span-2 {
        grid-column: span 1;
    }
}

@media print {
    .btn, form, .admin-sidebar, .admin-topbar {
        display: none !important;
    }
    
    .admin-main {
        margin-left: 0;
    }
    
    .card {
        box-shadow: none;
        border: 1px solid #e5e7eb;
    }
}
</style>

<?php
// Include footer
require_once __DIR__ . '/includes/footer.php';
?>
