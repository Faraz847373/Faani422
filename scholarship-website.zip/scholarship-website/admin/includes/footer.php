            </div>
            <!-- End Page Content -->
            
            <!-- Admin Footer -->
            <footer class="text-center text-sm text-gray-500 py-4 border-t bg-white">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Admin Panel v1.0</p>
            </footer>
        </div>
        <!-- End Main Content -->
    </div>
    
    <!-- JavaScript -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
    <script>
        // Toggle sidebar on mobile
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('open');
        }
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const menuBtn = document.querySelector('.mobile-menu-btn');
            
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
                    sidebar.classList.remove('open');
                }
            }
        });
    </script>
</body>
</html>
