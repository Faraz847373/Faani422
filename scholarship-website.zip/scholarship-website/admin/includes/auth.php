<?php
/**
 * ============================================================
 * Admin Authentication Functions
 * ============================================================
 * 
 * Handles admin login, logout, and session management.
 */

require_once __DIR__ . '/../../includes/functions.php';

/**
 * Check if admin is logged in
 * 
 * @return bool
 */
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Require admin authentication
 * Redirects to login page if not authenticated
 */
function requireAdminAuth() {
    if (!isAdminLoggedIn()) {
        setFlashMessage('error', 'Please login to access the admin panel.');
        redirect('login.php');
    }
    
    // Regenerate session ID periodically for security
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

/**
 * Attempt admin login
 * 
 * @param string $username Username or email
 * @param string $password Plain text password
 * @return array ['success' => bool, 'message' => string]
 */
function adminLogin($username, $password) {
    $db = db();
    
    // Find admin by username or email
    $admin = $db->fetchOne(
        "SELECT * FROM admin_users WHERE (username = :username OR email = :username) AND is_active = 1",
        ['username' => $username]
    );
    
    if (!$admin) {
        // Use generic message to prevent username enumeration
        return ['success' => false, 'message' => 'Invalid username or password'];
    }
    
    // Verify password
    if (!password_verify($password, $admin['password_hash'])) {
        return ['success' => false, 'message' => 'Invalid username or password'];
    }
    
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    // Set session variables
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_name'] = $admin['full_name'];
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['last_regeneration'] = time();
    
    // Update last login timestamp
    $db->update('admin_users', 
        ['last_login' => date('Y-m-d H:i:s')],
        'id = :id',
        ['id' => $admin['id']]
    );
    
    return ['success' => true, 'message' => 'Login successful'];
}

/**
 * Logout admin user
 */
function adminLogout() {
    // Unset all session variables
    $_SESSION = [];
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy session
    session_destroy();
}

/**
 * Get current admin user info
 * 
 * @return array|null Admin user data or null
 */
function getCurrentAdmin() {
    if (!isAdminLoggedIn()) {
        return null;
    }
    
    $db = db();
    return $db->fetchOne(
        "SELECT id, username, email, full_name, last_login FROM admin_users WHERE id = :id",
        ['id' => $_SESSION['admin_id']]
    );
}

/**
 * Change admin password
 * 
 * @param int $adminId Admin user ID
 * @param string $currentPassword Current password
 * @param string $newPassword New password
 * @return array ['success' => bool, 'message' => string]
 */
function changeAdminPassword($adminId, $currentPassword, $newPassword) {
    $db = db();
    
    // Get current admin
    $admin = $db->fetchOne(
        "SELECT * FROM admin_users WHERE id = :id",
        ['id' => $adminId]
    );
    
    if (!$admin) {
        return ['success' => false, 'message' => 'Admin user not found'];
    }
    
    // Verify current password
    if (!password_verify($currentPassword, $admin['password_hash'])) {
        return ['success' => false, 'message' => 'Current password is incorrect'];
    }
    
    // Validate new password
    if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
        return ['success' => false, 'message' => 'New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters'];
    }
    
    // Hash and update password
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $db->update('admin_users',
        ['password_hash' => $newHash],
        'id = :id',
        ['id' => $adminId]
    );
    
    return ['success' => true, 'message' => 'Password changed successfully'];
}

/**
 * Create new admin user (for setup purposes)
 * 
 * @param string $username Username
 * @param string $email Email
 * @param string $password Password
 * @param string $fullName Full name
 * @return array ['success' => bool, 'message' => string]
 */
function createAdminUser($username, $email, $password, $fullName) {
    $db = db();
    
    // Check if username exists
    $existing = $db->fetchOne(
        "SELECT id FROM admin_users WHERE username = :username OR email = :email",
        ['username' => $username, 'email' => $email]
    );
    
    if ($existing) {
        return ['success' => false, 'message' => 'Username or email already exists'];
    }
    
    // Validate password
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return ['success' => false, 'message' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters'];
    }
    
    // Create admin user
    $db->insert('admin_users', [
        'username' => $username,
        'email' => $email,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'full_name' => $fullName,
        'is_active' => 1
    ]);
    
    return ['success' => true, 'message' => 'Admin user created successfully'];
}
