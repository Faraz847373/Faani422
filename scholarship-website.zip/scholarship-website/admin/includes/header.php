<?php
/**
 * ============================================================
 * Admin Panel Header Template
 * ============================================================
 * 
 * Common header for all admin pages with sidebar navigation.
 */

require_once __DIR__ . '/auth.php';

// Require authentication for all admin pages except login
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
if ($currentPage !== 'login') {
    requireAdminAuth();
}

// Get current admin info
$currentAdmin = getCurrentAdmin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    
    <title><?php echo htmlspecialchars($pageTitle ?? 'Admin Panel'); ?> - <?php echo SITE_NAME; ?> Admin</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>⚙️</text></svg>">
    
    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    
    <style>
        /* Admin-specific styles */
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            width: 260px;
            background: linear-gradient(180deg, #1f2937 0%, #111827 100%);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
        }
        
        .admin-main {
            flex: 1;
            margin-left: 260px;
            background-color: #f3f4f6;
            min-height: 100vh;
        }
        
        .sidebar-brand {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-brand a {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: #ffffff;
            font-weight: 600;
            font-size: 1.125rem;
        }
        
        .sidebar-brand a:hover {
            text-decoration: none;
        }
        
        .sidebar-nav {
            padding: 1rem 0;
        }
        
        .sidebar-section {
            padding: 0.5rem 1.5rem;
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #6b7280;
            letter-spacing: 0.05em;
            margin-top: 1rem;
        }
        
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1.5rem;
            color: #9ca3af;
            transition: all 0.2s ease;
            border-left: 3px solid transparent;
        }
        
        .sidebar-link:hover {
            background-color: rgba(255,255,255,0.05);
            color: #ffffff;
            text-decoration: none;
        }
        
        .sidebar-link.active {
            background-color: rgba(59, 130, 246, 0.2);
            color: #60a5fa;
            border-left-color: #3b82f6;
        }
        
        .sidebar-link .icon {
            width: 20px;
            text-align: center;
        }
        
        .sidebar-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 1rem 1.5rem;
            border-top: 1px solid rgba(255,255,255,0.1);
            background: #111827;
        }
        
        .admin-topbar {
            background: #ffffff;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        
        .admin-content {
            padding: 2rem;
        }
        
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #1f2937;
        }
        
        .breadcrumb {
            display: flex;
            gap: 0.5rem;
            font-size: 0.875rem;
            color: #6b7280;
        }
        
        .breadcrumb a {
            color: #6b7280;
        }
        
        .breadcrumb a:hover {
            color: #3b82f6;
        }
        
        /* Mobile responsive */
        @media (max-width: 1024px) {
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .admin-sidebar.open {
                transform: translateX(0);
            }
            
            .admin-main {
                margin-left: 0;
            }
            
            .mobile-menu-btn {
                display: block !important;
            }
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar" id="sidebar">
            <!-- Brand -->
            <div class="sidebar-brand">
                <a href="index.php">
                    <span style="font-size: 1.5rem;">🎓</span>
                    <span>Admin Panel</span>
                </a>
            </div>
            
            <!-- Navigation -->
            <nav class="sidebar-nav">
                <div class="sidebar-section">Main</div>
                
                <a href="index.php" class="sidebar-link <?php echo $currentPage === 'index' ? 'active' : ''; ?>">
                    <span class="icon">📊</span>
                    <span>Dashboard</span>
                </a>
                
                <a href="applications.php" class="sidebar-link <?php echo $currentPage === 'applications' ? 'active' : ''; ?>">
                    <span class="icon">📋</span>
                    <span>Applications</span>
                </a>
                
                <div class="sidebar-section">Quick Filters</div>
                
                <a href="applications.php?status=pending" class="sidebar-link <?php echo ($currentPage === 'applications' && ($_GET['status'] ?? '') === 'pending') ? 'active' : ''; ?>">
                    <span class="icon">⏳</span>
                    <span>Pending</span>
                </a>
                
                <a href="applications.php?status=under_review" class="sidebar-link <?php echo ($currentPage === 'applications' && ($_GET['status'] ?? '') === 'under_review') ? 'active' : ''; ?>">
                    <span class="icon">🔍</span>
                    <span>Under Review</span>
                </a>
                
                <a href="applications.php?status=approved" class="sidebar-link <?php echo ($currentPage === 'applications' && ($_GET['status'] ?? '') === 'approved') ? 'active' : ''; ?>">
                    <span class="icon">✅</span>
                    <span>Approved</span>
                </a>
                
                <a href="applications.php?status=rejected" class="sidebar-link <?php echo ($currentPage === 'applications' && ($_GET['status'] ?? '') === 'rejected') ? 'active' : ''; ?>">
                    <span class="icon">❌</span>
                    <span>Rejected</span>
                </a>
                
                <div class="sidebar-section">Account</div>
                
                <a href="profile.php" class="sidebar-link <?php echo $currentPage === 'profile' ? 'active' : ''; ?>">
                    <span class="icon">👤</span>
                    <span>My Profile</span>
                </a>
                
                <a href="logout.php" class="sidebar-link">
                    <span class="icon">🚪</span>
                    <span>Logout</span>
                </a>
            </nav>
            
            <!-- Footer -->
            <div class="sidebar-footer">
                <a href="<?php echo SITE_URL; ?>" target="_blank" class="text-sm text-gray-400 hover:text-white">
                    ← View Website
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <div class="admin-main">
            <!-- Top Bar -->
            <header class="admin-topbar">
                <div class="flex items-center gap-4">
                    <button class="mobile-menu-btn" onclick="toggleSidebar()">☰</button>
                    <div class="breadcrumb">
                        <a href="index.php">Admin</a>
                        <span>/</span>
                        <span><?php echo htmlspecialchars($pageTitle ?? 'Dashboard'); ?></span>
                    </div>
                </div>
                
                <div class="flex items-center gap-4">
                    <span class="text-sm text-gray-600">
                        Welcome, <strong><?php echo htmlspecialchars($currentAdmin['full_name'] ?? 'Admin'); ?></strong>
                    </span>
                    <a href="logout.php" class="btn btn-sm btn-secondary">Logout</a>
                </div>
            </header>
            
            <!-- Page Content -->
            <div class="admin-content">
                <!-- Flash Messages -->
                <?php echo displayFlashMessages(); ?>
