<?php
/**
 * ============================================================
 * Admin Login Page
 * ============================================================
 * 
 * Secure login page for administrators.
 */

require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isAdminLoggedIn()) {
    redirect('index.php');
}

// Page metadata
$pageTitle = 'Admin Login';

// Handle login form submission
$error = '';
$username = '';

if (isPost()) {
    // Validate CSRF token
    if (!validateCSRFToken()) {
        $error = 'Invalid request. Please try again.';
    } else {
        $username = sanitizeString($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            $result = adminLogin($username, $password);
            
            if ($result['success']) {
                setFlashMessage('success', 'Welcome back, ' . $_SESSION['admin_name'] . '!');
                redirect('index.php');
            } else {
                $error = $result['message'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    
    <title><?php echo $pageTitle; ?> - <?php echo SITE_NAME; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔐</text></svg>">
    
    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .login-container {
            width: 100%;
            max-width: 400px;
        }
        
        .login-card {
            background: #ffffff;
            border-radius: 1rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            overflow: hidden;
        }
        
        .login-header {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
            padding: 2rem;
            text-align: center;
            color: #ffffff;
        }
        
        .login-header .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .login-header h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .login-header p {
            font-size: 0.875rem;
            opacity: 0.8;
        }
        
        .login-body {
            padding: 2rem;
        }
        
        .login-footer {
            padding: 1rem 2rem;
            background: #f9fafb;
            text-align: center;
            border-top: 1px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <!-- Header -->
            <div class="login-header">
                <div class="icon">🔐</div>
                <h1>Admin Login</h1>
                <p><?php echo SITE_NAME; ?></p>
            </div>
            
            <!-- Body -->
            <div class="login-body">
                <?php if ($error): ?>
                <div class="alert alert-error mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php echo displayFlashMessages(); ?>
                
                <form method="POST" action="login.php" data-validate>
                    <?php echo csrfField(); ?>
                    
                    <div class="form-group">
                        <label for="username" class="form-label">Username or Email</label>
                        <input type="text" 
                               id="username" 
                               name="username" 
                               class="form-input"
                               value="<?php echo htmlspecialchars($username); ?>"
                               placeholder="Enter your username"
                               required
                               autofocus>
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" 
                               id="password" 
                               name="password" 
                               class="form-input"
                               placeholder="Enter your password"
                               required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block btn-lg mt-6">
                        Sign In
                    </button>
                </form>
            </div>
            
            <!-- Footer -->
            <div class="login-footer">
                <a href="<?php echo SITE_URL; ?>" class="text-sm text-gray-600">
                    ← Back to Website
                </a>
            </div>
        </div>
        
        <!-- Security Notice -->
        <p class="text-center text-white text-sm mt-6 opacity-75">
            🔒 This is a secure area. Unauthorized access is prohibited.
        </p>
    </div>
    
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
