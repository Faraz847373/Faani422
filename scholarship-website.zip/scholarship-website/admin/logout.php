<?php
/**
 * ============================================================
 * Admin Logout
 * ============================================================
 * 
 * Handles admin logout and session destruction.
 */

require_once __DIR__ . '/includes/auth.php';

// Perform logout
adminLogout();

// Start new session for flash message
session_start();
setFlashMessage('success', 'You have been logged out successfully.');

// Redirect to login page
redirect('login.php');
