<?php
/**
 * ============================================================
 * Admin Applications List
 * ============================================================
 * 
 * Lists all applications with filtering, search, and
 * pagination capabilities.
 */

// Page metadata
$pageTitle = 'Applications';

// Include header (handles authentication)
require_once __DIR__ . '/includes/header.php';

// Handle CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    exportApplicationsCSV();
    exit;
}

// Handle bulk actions
if (isPost() && isset($_POST['action'])) {
    if (!validateCSRFToken()) {
        setFlashMessage('error', 'Invalid request. Please try again.');
        redirect('applications.php');
    }
    
    $action = $_POST['action'];
    $applicationIds = $_POST['application_ids'] ?? [];
    
    if (!empty($applicationIds) && is_array($applicationIds)) {
        $db = db();
        
        if ($action === 'bulk_approve') {
            foreach ($applicationIds as $id) {
                $db->update('applications', ['status' => 'approved'], 'id = :id', ['id' => intval($id)]);
            }
            setFlashMessage('success', count($applicationIds) . ' application(s) approved.');
        } elseif ($action === 'bulk_reject') {
            foreach ($applicationIds as $id) {
                $db->update('applications', ['status' => 'rejected'], 'id = :id', ['id' => intval($id)]);
            }
            setFlashMessage('success', count($applicationIds) . ' application(s) rejected.');
        } elseif ($action === 'bulk_delete') {
            foreach ($applicationIds as $id) {
                $db->query("DELETE FROM applications WHERE id = :id", ['id' => intval($id)]);
            }
            setFlashMessage('success', count($applicationIds) . ' application(s) deleted.');
        }
    }
    
    redirect('applications.php' . (isset($_GET['status']) ? '?status=' . $_GET['status'] : ''));
}

// Pagination settings
$perPage = 20;
$currentPage = max(1, intval($_GET['page'] ?? 1));
$offset = ($currentPage - 1) * $perPage;

// Filter parameters
$statusFilter = sanitizeString($_GET['status'] ?? '');
$searchQuery = sanitizeString($_GET['search'] ?? '');

// Build query
$whereConditions = [];
$params = [];

if ($statusFilter && in_array($statusFilter, ['pending', 'under_review', 'approved', 'rejected'])) {
    $whereConditions[] = "status = :status";
    $params['status'] = $statusFilter;
}

if ($searchQuery) {
    $whereConditions[] = "(full_name LIKE :search OR cnic LIKE :search2 OR reference_number LIKE :search3 OR email LIKE :search4)";
    $params['search'] = "%{$searchQuery}%";
    $params['search2'] = "%{$searchQuery}%";
    $params['search3'] = "%{$searchQuery}%";
    $params['search4'] = "%{$searchQuery}%";
}

$whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// Get total count
$db = db();
$totalCount = $db->count("SELECT COUNT(*) FROM applications {$whereClause}", $params);
$totalPages = ceil($totalCount / $perPage);

// Get applications
$applications = $db->fetchAll(
    "SELECT * FROM applications {$whereClause} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}",
    $params
);

/**
 * Export applications to CSV
 */
function exportApplicationsCSV() {
    $db = db();
    $applications = $db->fetchAll("SELECT * FROM applications ORDER BY created_at DESC");
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="applications_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Header row
    fputcsv($output, [
        'Reference Number', 'Full Name', 'Father Name', 'CNIC', 'Email', 'Phone',
        'Qualification', 'Monthly Income', 'Address', 'Status', 'Submitted Date'
    ]);
    
    // Data rows
    foreach ($applications as $app) {
        fputcsv($output, [
            $app['reference_number'],
            $app['full_name'],
            $app['father_name'],
            $app['cnic'],
            $app['email'],
            $app['phone'],
            $app['qualification'],
            $app['monthly_income'],
            $app['address'],
            $app['status'],
            $app['created_at']
        ]);
    }
    
    fclose($output);
}
?>

<!-- Page Header -->
<div class="page-header flex justify-between items-center">
    <div>
        <h1 class="page-title">Applications</h1>
        <p class="text-gray-600">
            <?php if ($statusFilter): ?>
                Showing <?php echo getStatusLabel($statusFilter); ?> applications
            <?php else: ?>
                Manage all scholarship applications
            <?php endif; ?>
        </p>
    </div>
    <div class="flex gap-2">
        <a href="applications.php?export=csv" class="btn btn-secondary">
            📥 Export CSV
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-6">
    <form method="GET" action="applications.php" class="flex flex-wrap gap-4 items-end">
        <!-- Search -->
        <div class="flex-1 min-w-[200px]">
            <label class="form-label">Search</label>
            <input type="text" 
                   name="search" 
                   class="form-input"
                   value="<?php echo htmlspecialchars($searchQuery); ?>"
                   placeholder="Name, CNIC, Reference, or Email">
        </div>
        
        <!-- Status Filter -->
        <div class="w-48">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="">All Statuses</option>
                <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="under_review" <?php echo $statusFilter === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                <option value="approved" <?php echo $statusFilter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
            </select>
        </div>
        
        <!-- Buttons -->
        <div class="flex gap-2">
            <button type="submit" class="btn btn-primary">
                🔍 Filter
            </button>
            <a href="applications.php" class="btn btn-secondary">
                Clear
            </a>
        </div>
    </form>
</div>

<!-- Results Info -->
<div class="flex justify-between items-center mb-4">
    <p class="text-sm text-gray-600">
        Showing <?php echo number_format(min($offset + 1, $totalCount)); ?> - <?php echo number_format(min($offset + $perPage, $totalCount)); ?> 
        of <?php echo number_format($totalCount); ?> applications
    </p>
</div>

<!-- Applications Table -->
<div class="card">
    <?php if (empty($applications)): ?>
    <div class="text-center py-12 text-gray-500">
        <div class="text-5xl mb-4">📭</div>
        <h3 class="text-lg font-semibold mb-2">No applications found</h3>
        <p>
            <?php if ($searchQuery || $statusFilter): ?>
                Try adjusting your filters or search query.
            <?php else: ?>
                No applications have been submitted yet.
            <?php endif; ?>
        </p>
    </div>
    <?php else: ?>
    <form method="POST" action="applications.php<?php echo $statusFilter ? '?status=' . $statusFilter : ''; ?>" id="bulkForm">
        <?php echo csrfField(); ?>
        
        <!-- Bulk Actions -->
        <div class="flex gap-2 mb-4 p-4 bg-gray-50 rounded-lg">
            <select name="action" class="form-select w-48" id="bulkAction">
                <option value="">Bulk Actions</option>
                <option value="bulk_approve">Approve Selected</option>
                <option value="bulk_reject">Reject Selected</option>
                <option value="bulk_delete">Delete Selected</option>
            </select>
            <button type="submit" class="btn btn-secondary" onclick="return confirmBulkAction()">
                Apply
            </button>
            <span class="text-sm text-gray-500 self-center ml-2">
                <span id="selectedCount">0</span> selected
            </span>
        </div>
        
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th class="w-10">
                            <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                        </th>
                        <th>Reference</th>
                        <th>Applicant</th>
                        <th>CNIC</th>
                        <th>Qualification</th>
                        <th>Income</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                    <tr>
                        <td>
                            <input type="checkbox" 
                                   name="application_ids[]" 
                                   value="<?php echo $app['id']; ?>"
                                   class="row-checkbox"
                                   onchange="updateSelectedCount()">
                        </td>
                        <td>
                            <span class="font-mono text-sm"><?php echo htmlspecialchars($app['reference_number']); ?></span>
                        </td>
                        <td>
                            <div>
                                <strong><?php echo htmlspecialchars($app['full_name']); ?></strong>
                                <div class="text-xs text-gray-500"><?php echo htmlspecialchars($app['email']); ?></div>
                            </div>
                        </td>
                        <td><?php echo htmlspecialchars($app['cnic']); ?></td>
                        <td><?php echo htmlspecialchars($app['qualification']); ?></td>
                        <td><?php echo formatCurrency($app['monthly_income']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $app['status']; ?>">
                                <?php echo getStatusLabel($app['status']); ?>
                            </span>
                        </td>
                        <td class="text-sm text-gray-500">
                            <?php echo formatDate($app['created_at'], 'M d, Y'); ?>
                        </td>
                        <td>
                            <div class="flex gap-1">
                                <a href="view.php?id=<?php echo $app['id']; ?>" 
                                   class="btn btn-sm btn-primary" 
                                   title="View Details">
                                    👁️
                                </a>
                                <button type="button" 
                                        onclick="quickStatusUpdate(<?php echo $app['id']; ?>)"
                                        class="btn btn-sm btn-secondary"
                                        title="Quick Status Update">
                                    ✏️
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </form>
    
    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="flex justify-center gap-2 mt-6">
        <?php if ($currentPage > 1): ?>
        <a href="?page=<?php echo $currentPage - 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchQuery); ?>" 
           class="btn btn-secondary">
            ← Previous
        </a>
        <?php endif; ?>
        
        <?php
        $startPage = max(1, $currentPage - 2);
        $endPage = min($totalPages, $currentPage + 2);
        
        for ($i = $startPage; $i <= $endPage; $i++):
        ?>
        <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchQuery); ?>" 
           class="btn <?php echo $i === $currentPage ? 'btn-primary' : 'btn-secondary'; ?>">
            <?php echo $i; ?>
        </a>
        <?php endfor; ?>
        
        <?php if ($currentPage < $totalPages): ?>
        <a href="?page=<?php echo $currentPage + 1; ?>&status=<?php echo $statusFilter; ?>&search=<?php echo urlencode($searchQuery); ?>" 
           class="btn btn-secondary">
            Next →
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Quick Status Update Modal -->
<div id="statusModal" class="modal" style="display: none;">
    <div class="modal-backdrop" onclick="closeModal()"></div>
    <div class="modal-content">
        <h3 class="text-lg font-semibold mb-4">Update Status</h3>
        <form method="POST" action="view.php" id="quickStatusForm">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="application_id" id="modalAppId">
            
            <div class="form-group">
                <label class="form-label">New Status</label>
                <select name="status" class="form-select" required>
                    <option value="pending">Pending</option>
                    <option value="under_review">Under Review</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
            
            <div class="flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">Update</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
}

.modal-content {
    position: relative;
    background: white;
    padding: 1.5rem;
    border-radius: 0.5rem;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
}
</style>

<script>
// Select all checkbox
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.row-checkbox');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
    updateSelectedCount();
}

// Update selected count
function updateSelectedCount() {
    const checked = document.querySelectorAll('.row-checkbox:checked').length;
    document.getElementById('selectedCount').textContent = checked;
}

// Confirm bulk action
function confirmBulkAction() {
    const action = document.getElementById('bulkAction').value;
    const checked = document.querySelectorAll('.row-checkbox:checked').length;
    
    if (!action) {
        alert('Please select an action');
        return false;
    }
    
    if (checked === 0) {
        alert('Please select at least one application');
        return false;
    }
    
    const messages = {
        'bulk_approve': 'approve',
        'bulk_reject': 'reject',
        'bulk_delete': 'permanently delete'
    };
    
    return confirm(`Are you sure you want to ${messages[action]} ${checked} application(s)?`);
}

// Quick status update modal
function quickStatusUpdate(appId) {
    document.getElementById('modalAppId').value = appId;
    document.getElementById('quickStatusForm').action = 'view.php?id=' + appId;
    document.getElementById('statusModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('statusModal').style.display = 'none';
}

// Close modal on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});
</script>

<?php
// Include footer
require_once __DIR__ . '/includes/footer.php';
?>
