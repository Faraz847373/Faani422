<?php
/**
 * ============================================================
 * Admin Profile Page
 * ============================================================
 * 
 * Allows administrators to view and update their profile
 * and change their password.
 */

// Page metadata
$pageTitle = 'My Profile';

// Include header (handles authentication)
require_once __DIR__ . '/includes/header.php';

// Get current admin details
$admin = getCurrentAdmin();

// Handle form submissions
$errors = [];
$success = '';

if (isPost()) {
    if (!validateCSRFToken()) {
        setFlashMessage('error', 'Invalid request. Please try again.');
        redirect('profile.php');
    }
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $fullName = sanitizeString($_POST['full_name'] ?? '');
        $email = sanitizeEmail($_POST['email'] ?? '');
        
        if (empty($fullName)) {
            $errors['full_name'] = 'Full name is required';
        }
        
        if (!$email) {
            $errors['email'] = 'Valid email is required';
        } else {
            // Check if email is taken by another admin
            $db = db();
            $existing = $db->fetchOne(
                "SELECT id FROM admin_users WHERE email = :email AND id != :id",
                ['email' => $email, 'id' => $admin['id']]
            );
            if ($existing) {
                $errors['email'] = 'This email is already in use';
            }
        }
        
        if (empty($errors)) {
            $db = db();
            $db->update('admin_users',
                [
                    'full_name' => $fullName,
                    'email' => $email
                ],
                'id = :id',
                ['id' => $admin['id']]
            );
            
            $_SESSION['admin_name'] = $fullName;
            setFlashMessage('success', 'Profile updated successfully.');
            redirect('profile.php');
        }
    } elseif ($action === 'change_password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (empty($currentPassword)) {
            $errors['current_password'] = 'Current password is required';
        }
        
        if (empty($newPassword)) {
            $errors['new_password'] = 'New password is required';
        } elseif (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            $errors['new_password'] = 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters';
        }
        
        if ($newPassword !== $confirmPassword) {
            $errors['confirm_password'] = 'Passwords do not match';
        }
        
        if (empty($errors)) {
            $result = changeAdminPassword($admin['id'], $currentPassword, $newPassword);
            
            if ($result['success']) {
                setFlashMessage('success', 'Password changed successfully.');
                redirect('profile.php');
            } else {
                $errors['current_password'] = $result['message'];
            }
        }
    }
}

// Refresh admin data
$admin = getCurrentAdmin();
?>

<!-- Page Header -->
<div class="page-header">
    <h1 class="page-title">My Profile</h1>
    <p class="text-gray-600">Manage your account settings and password</p>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Profile Information -->
    <div class="card">
        <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Profile Information</h3>
        
        <form method="POST" action="profile.php">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="update_profile">
            
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" 
                       class="form-input bg-gray-100" 
                       value="<?php echo htmlspecialchars($admin['username']); ?>"
                       disabled>
                <span class="form-hint">Username cannot be changed</span>
            </div>
            
            <div class="form-group">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" 
                       id="full_name"
                       name="full_name" 
                       class="form-input <?php echo isset($errors['full_name']) ? 'error' : ''; ?>"
                       value="<?php echo htmlspecialchars($_POST['full_name'] ?? $admin['full_name']); ?>"
                       required>
                <?php if (isset($errors['full_name'])): ?>
                <span class="form-error"><?php echo $errors['full_name']; ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" 
                       id="email"
                       name="email" 
                       class="form-input <?php echo isset($errors['email']) ? 'error' : ''; ?>"
                       value="<?php echo htmlspecialchars($_POST['email'] ?? $admin['email']); ?>"
                       required>
                <?php if (isset($errors['email'])): ?>
                <span class="form-error"><?php echo $errors['email']; ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label class="form-label">Last Login</label>
                <input type="text" 
                       class="form-input bg-gray-100" 
                       value="<?php echo $admin['last_login'] ? formatDate($admin['last_login']) : 'Never'; ?>"
                       disabled>
            </div>
            
            <button type="submit" class="btn btn-primary">
                Save Changes
            </button>
        </form>
    </div>
    
    <!-- Change Password -->
    <div class="card">
        <h3 class="text-lg font-semibold mb-4 pb-2 border-b">Change Password</h3>
        
        <form method="POST" action="profile.php">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="change_password">
            
            <div class="form-group">
                <label for="current_password" class="form-label">Current Password</label>
                <input type="password" 
                       id="current_password"
                       name="current_password" 
                       class="form-input <?php echo isset($errors['current_password']) ? 'error' : ''; ?>"
                       required>
                <?php if (isset($errors['current_password'])): ?>
                <span class="form-error"><?php echo $errors['current_password']; ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" 
                       id="new_password"
                       name="new_password" 
                       class="form-input <?php echo isset($errors['new_password']) ? 'error' : ''; ?>"
                       minlength="<?php echo PASSWORD_MIN_LENGTH; ?>"
                       required>
                <span class="form-hint">Minimum <?php echo PASSWORD_MIN_LENGTH; ?> characters</span>
                <?php if (isset($errors['new_password'])): ?>
                <span class="form-error"><?php echo $errors['new_password']; ?></span>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" 
                       id="confirm_password"
                       name="confirm_password" 
                       class="form-input <?php echo isset($errors['confirm_password']) ? 'error' : ''; ?>"
                       required>
                <?php if (isset($errors['confirm_password'])): ?>
                <span class="form-error"><?php echo $errors['confirm_password']; ?></span>
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">
                Change Password
            </button>
        </form>
    </div>
</div>

<!-- Security Tips -->
<div class="card mt-6">
    <h3 class="text-lg font-semibold mb-4">Security Tips</h3>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="p-4 bg-gray-50 rounded-lg">
            <div class="text-2xl mb-2">🔐</div>
            <h4 class="font-medium mb-1">Strong Password</h4>
            <p class="text-sm text-gray-600">
                Use a mix of letters, numbers, and special characters.
            </p>
        </div>
        <div class="p-4 bg-gray-50 rounded-lg">
            <div class="text-2xl mb-2">🔄</div>
            <h4 class="font-medium mb-1">Regular Updates</h4>
            <p class="text-sm text-gray-600">
                Change your password every 90 days for better security.
            </p>
        </div>
        <div class="p-4 bg-gray-50 rounded-lg">
            <div class="text-2xl mb-2">🚪</div>
            <h4 class="font-medium mb-1">Logout</h4>
            <p class="text-sm text-gray-600">
                Always logout when using shared or public computers.
            </p>
        </div>
    </div>
</div>

<?php
// Include footer
require_once __DIR__ . '/includes/footer.php';
?>
