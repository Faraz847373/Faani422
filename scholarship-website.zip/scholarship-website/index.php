<?php
/**
 * ============================================================
 * Root Index - Redirect to Public Directory
 * ============================================================
 * 
 * This file redirects visitors to the public directory.
 * In production, configure your web server to point directly
 * to the /public directory as the document root.
 */

// Redirect to public directory
header('Location: public/index.php');
exit;
