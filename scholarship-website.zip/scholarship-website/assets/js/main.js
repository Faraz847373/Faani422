/**
 * ============================================================
 * Scholarship Application Website - Main JavaScript
 * ============================================================
 * 
 * Handles client-side form validation, file uploads, and
 * interactive features using vanilla JavaScript.
 */

// ============================================================
// DOM Ready Handler
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initFormValidation();
    initFileUploads();
    initCNICFormatting();
    initPhoneFormatting();
    initFormSubmission();
    initStatusCheck();
});

// ============================================================
// Form Validation
// ============================================================

/**
 * Initialize form validation for all forms with data-validate attribute
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        // Add real-time validation on blur
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            // Clear error on input
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    });
}

/**
 * Validate a single form field
 * 
 * @param {HTMLElement} field - The form field to validate
 * @returns {boolean} - Whether the field is valid
 */
function validateField(field) {
    const value = field.value.trim();
    const type = field.type;
    const name = field.name;
    const required = field.hasAttribute('required');
    
    // Clear previous errors
    clearFieldError(field);
    
    // Required field check
    if (required && !value) {
        showFieldError(field, 'This field is required');
        return false;
    }
    
    // Skip further validation if empty and not required
    if (!value) return true;
    
    // Email validation
    if (type === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            showFieldError(field, 'Please enter a valid email address');
            return false;
        }
    }
    
    // Phone validation
    if (name === 'phone') {
        const phoneRegex = /^[\d\s\-+()]{10,20}$/;
        if (!phoneRegex.test(value)) {
            showFieldError(field, 'Please enter a valid phone number');
            return false;
        }
    }
    
    // CNIC validation
    if (name === 'cnic') {
        const cnicDigits = value.replace(/[^0-9]/g, '');
        if (cnicDigits.length !== 13) {
            showFieldError(field, 'CNIC must be 13 digits (XXXXX-XXXXXXX-X)');
            return false;
        }
    }
    
    // Monthly income validation
    if (name === 'monthly_income') {
        const amount = parseFloat(value.replace(/[^0-9.]/g, ''));
        if (isNaN(amount) || amount < 0) {
            showFieldError(field, 'Please enter a valid amount');
            return false;
        }
    }
    
    // Minimum length validation
    const minLength = field.getAttribute('minlength');
    if (minLength && value.length < parseInt(minLength)) {
        showFieldError(field, `Minimum ${minLength} characters required`);
        return false;
    }
    
    // Maximum length validation
    const maxLength = field.getAttribute('maxlength');
    if (maxLength && value.length > parseInt(maxLength)) {
        showFieldError(field, `Maximum ${maxLength} characters allowed`);
        return false;
    }
    
    return true;
}

/**
 * Show error message for a field
 * 
 * @param {HTMLElement} field - The form field
 * @param {string} message - Error message to display
 */
function showFieldError(field, message) {
    field.classList.add('error');
    
    // Create error element if it doesn't exist
    let errorEl = field.parentNode.querySelector('.form-error');
    if (!errorEl) {
        errorEl = document.createElement('span');
        errorEl.className = 'form-error';
        field.parentNode.appendChild(errorEl);
    }
    
    errorEl.textContent = message;
}

/**
 * Clear error message for a field
 * 
 * @param {HTMLElement} field - The form field
 */
function clearFieldError(field) {
    field.classList.remove('error');
    
    const errorEl = field.parentNode.querySelector('.form-error');
    if (errorEl) {
        errorEl.remove();
    }
}

/**
 * Validate entire form
 * 
 * @param {HTMLFormElement} form - The form to validate
 * @returns {boolean} - Whether the form is valid
 */
function validateForm(form) {
    const fields = form.querySelectorAll('input, select, textarea');
    let isValid = true;
    
    fields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    // Validate file uploads
    const fileInputs = form.querySelectorAll('input[type="file"][required]');
    fileInputs.forEach(input => {
        if (!input.files || input.files.length === 0) {
            showFieldError(input, 'Please select a file');
            isValid = false;
        }
    });
    
    return isValid;
}

// ============================================================
// File Upload Handling
// ============================================================

/**
 * Initialize file upload components
 */
function initFileUploads() {
    const fileInputs = document.querySelectorAll('.file-input');
    
    fileInputs.forEach(input => {
        const wrapper = input.closest('.file-input-wrapper');
        const label = wrapper.querySelector('.file-input-label');
        const fileNameEl = wrapper.querySelector('.file-name');
        
        // Handle file selection
        input.addEventListener('change', function() {
            handleFileSelect(this, fileNameEl);
        });
        
        // Drag and drop support
        if (label) {
            label.addEventListener('dragover', function(e) {
                e.preventDefault();
                this.classList.add('dragover');
            });
            
            label.addEventListener('dragleave', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
            });
            
            label.addEventListener('drop', function(e) {
                e.preventDefault();
                this.classList.remove('dragover');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    input.files = files;
                    handleFileSelect(input, fileNameEl);
                }
            });
        }
    });
}

/**
 * Handle file selection and validation
 * 
 * @param {HTMLInputElement} input - File input element
 * @param {HTMLElement} fileNameEl - Element to display file name
 */
function handleFileSelect(input, fileNameEl) {
    clearFieldError(input);
    
    if (!input.files || input.files.length === 0) {
        if (fileNameEl) fileNameEl.textContent = '';
        return;
    }
    
    const file = input.files[0];
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    const allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png'];
    
    // Get file extension
    const extension = file.name.split('.').pop().toLowerCase();
    
    // Validate file type
    if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(extension)) {
        showFieldError(input, 'Invalid file type. Allowed: PDF, JPG, PNG');
        input.value = '';
        if (fileNameEl) fileNameEl.textContent = '';
        return;
    }
    
    // Validate file size
    if (file.size > maxSize) {
        showFieldError(input, 'File size exceeds 5MB limit');
        input.value = '';
        if (fileNameEl) fileNameEl.textContent = '';
        return;
    }
    
    // Display file name
    if (fileNameEl) {
        fileNameEl.textContent = `Selected: ${file.name} (${formatFileSize(file.size)})`;
    }
}

/**
 * Format file size for display
 * 
 * @param {number} bytes - File size in bytes
 * @returns {string} - Formatted file size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ============================================================
// Input Formatting
// ============================================================

/**
 * Initialize CNIC input formatting
 */
function initCNICFormatting() {
    const cnicInputs = document.querySelectorAll('input[name="cnic"]');
    
    cnicInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            let value = this.value.replace(/[^0-9]/g, '');
            
            // Format as XXXXX-XXXXXXX-X
            if (value.length > 5) {
                value = value.substring(0, 5) + '-' + value.substring(5);
            }
            if (value.length > 13) {
                value = value.substring(0, 13) + '-' + value.substring(13);
            }
            if (value.length > 15) {
                value = value.substring(0, 15);
            }
            
            this.value = value;
        });
        
        // Set placeholder
        input.placeholder = 'XXXXX-XXXXXXX-X';
    });
}

/**
 * Initialize phone input formatting
 */
function initPhoneFormatting() {
    const phoneInputs = document.querySelectorAll('input[name="phone"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            // Allow only digits, spaces, dashes, and plus sign
            this.value = this.value.replace(/[^0-9\s\-+]/g, '');
        });
        
        // Set placeholder
        input.placeholder = '03XX-XXXXXXX';
    });
}

// ============================================================
// Form Submission
// ============================================================

/**
 * Initialize form submission handling
 */
function initFormSubmission() {
    const applicationForm = document.getElementById('applicationForm');
    
    if (applicationForm) {
        applicationForm.addEventListener('submit', function(e) {
            // Validate form
            if (!validateForm(this)) {
                e.preventDefault();
                
                // Scroll to first error
                const firstError = this.querySelector('.error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                
                return false;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('btn-loading');
                submitBtn.setAttribute('data-original-text', submitBtn.textContent);
            }
        });
    }
}

// ============================================================
// Status Check
// ============================================================

/**
 * Initialize status check functionality
 */
function initStatusCheck() {
    const statusForm = document.getElementById('statusForm');
    
    if (statusForm) {
        statusForm.addEventListener('submit', function(e) {
            const input = this.querySelector('input[name="search"]');
            
            if (!input.value.trim()) {
                e.preventDefault();
                showFieldError(input, 'Please enter your CNIC or Reference Number');
                return false;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('btn-loading');
            }
        });
    }
}

// ============================================================
// Utility Functions
// ============================================================

/**
 * Show a notification message
 * 
 * @param {string} message - Message to display
 * @param {string} type - Message type (success, error, warning, info)
 */
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification alert alert-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

/**
 * Confirm action with dialog
 * 
 * @param {string} message - Confirmation message
 * @returns {boolean} - User's choice
 */
function confirmAction(message) {
    return confirm(message);
}

/**
 * Format currency for display
 * 
 * @param {number} amount - Amount to format
 * @returns {string} - Formatted amount
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PK', {
        style: 'currency',
        currency: 'PKR',
        minimumFractionDigits: 0
    }).format(amount);
}

// ============================================================
// Admin Panel Functions
// ============================================================

/**
 * Update application status via AJAX
 * 
 * @param {number} applicationId - Application ID
 * @param {string} newStatus - New status value
 */
function updateStatus(applicationId, newStatus) {
    if (!confirmAction('Are you sure you want to update the status?')) {
        return;
    }
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="action" value="update_status">
        <input type="hidden" name="application_id" value="${applicationId}">
        <input type="hidden" name="status" value="${newStatus}">
    `;
    
    // Add CSRF token if available
    const csrfToken = document.querySelector('input[name="csrf_token"]');
    if (csrfToken) {
        form.appendChild(csrfToken.cloneNode());
    }
    
    document.body.appendChild(form);
    form.submit();
}

/**
 * Delete application with confirmation
 * 
 * @param {number} applicationId - Application ID
 */
function deleteApplication(applicationId) {
    if (!confirmAction('Are you sure you want to delete this application? This action cannot be undone.')) {
        return;
    }
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="application_id" value="${applicationId}">
    `;
    
    // Add CSRF token if available
    const csrfToken = document.querySelector('input[name="csrf_token"]');
    if (csrfToken) {
        form.appendChild(csrfToken.cloneNode());
    }
    
    document.body.appendChild(form);
    form.submit();
}

// ============================================================
// CSS Animations (injected via JS)
// ============================================================
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
