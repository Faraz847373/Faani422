    </main>
    <!-- End Main Content -->
    
    <!-- Footer -->
    <footer class="footer mt-12">
        <div class="container">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- About Section -->
                <div>
                    <h3 class="text-lg font-semibold text-white mb-4">About Us</h3>
                    <p class="text-sm leading-relaxed">
                        We are committed to supporting deserving students in achieving their 
                        educational goals through our scholarship programs.
                    </p>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h3 class="text-lg font-semibold text-white mb-4">Quick Links</h3>
                    <ul class="text-sm">
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/index.php">Home</a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/apply.php">Apply for Scholarship</a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo SITE_URL; ?>/status.php">Check Application Status</a>
                        </li>
                    </ul>
                </div>
                
                <!-- Contact Info -->
                <div>
                    <h3 class="text-lg font-semibold text-white mb-4">Contact Us</h3>
                    <ul class="text-sm">
                        <li class="mb-2">
                            📧 Email: <a href="mailto:<?php echo ADMIN_EMAIL; ?>"><?php echo ADMIN_EMAIL; ?></a>
                        </li>
                        <li class="mb-2">
                            📞 Phone: +92-XXX-XXXXXXX
                        </li>
                        <li class="mb-2">
                            📍 Address: Your Organization Address
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Copyright -->
            <div class="border-t border-gray-700 mt-8 pt-6 text-center text-sm">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
