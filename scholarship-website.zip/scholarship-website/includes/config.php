<?php
/**
 * ============================================================
 * Scholarship Application Website - Configuration File
 * ============================================================
 * 
 * This file contains all configuration settings for the application.
 * IMPORTANT: Update these values before deploying to production!
 * 
 * Security Note: In production, consider moving this file outside
 * the web root or using environment variables.
 */

// ============================================================
// Error Reporting (disable in production)
// ============================================================
// Development: Show all errors
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Production: Hide errors, log them instead
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// ============================================================
// Database Configuration
// ============================================================
define('DB_HOST', 'localhost');          // Database host
define('DB_NAME', 'scholarship_db');     // Database name
define('DB_USER', 'root');               // Database username
define('DB_PASS', '');                   // Database password
define('DB_CHARSET', 'utf8mb4');         // Character set

// ============================================================
// Application Settings
// ============================================================
define('SITE_NAME', 'Scholarship Portal');
define('SITE_URL', 'http://localhost');  // Update with your domain
define('ADMIN_EMAIL', 'admin@example.com');

// ============================================================
// File Upload Settings
// ============================================================
define('UPLOAD_DIR', __DIR__ . '/../uploads/applications/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024);  // 5MB max file size
define('ALLOWED_EXTENSIONS', ['pdf', 'jpg', 'jpeg', 'png']);
define('ALLOWED_MIME_TYPES', [
    'application/pdf',
    'image/jpeg',
    'image/png'
]);

// ============================================================
// Session Configuration
// ============================================================
define('SESSION_NAME', 'scholarship_session');
define('SESSION_LIFETIME', 3600);  // 1 hour

// ============================================================
// Security Settings
// ============================================================
define('CSRF_TOKEN_NAME', 'csrf_token');
define('PASSWORD_MIN_LENGTH', 8);

// ============================================================
// Application Status Labels
// ============================================================
define('STATUS_LABELS', [
    'pending' => 'Pending Review',
    'under_review' => 'Under Review',
    'approved' => 'Approved',
    'rejected' => 'Rejected'
]);

define('STATUS_COLORS', [
    'pending' => '#f59e0b',      // Amber
    'under_review' => '#3b82f6', // Blue
    'approved' => '#10b981',     // Green
    'rejected' => '#ef4444'      // Red
]);

// ============================================================
// Timezone Setting
// ============================================================
date_default_timezone_set('Asia/Karachi');  // Update as needed

// ============================================================
// Start Session with Secure Settings
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    // Set session cookie parameters for security
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']),  // Only send over HTTPS
        'httponly' => true,                     // Prevent JavaScript access
        'samesite' => 'Strict'                  // CSRF protection
    ]);
    
    session_name(SESSION_NAME);
    session_start();
}
