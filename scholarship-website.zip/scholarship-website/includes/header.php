<?php
/**
 * ============================================================
 * Header Template
 * ============================================================
 * 
 * Common header included on all public pages.
 * Sets the page title and includes navigation.
 */

// Get current page for active nav highlighting
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription ?? 'Apply for scholarships online. Submit your application and track your status.'); ?>">
    
    <title><?php echo htmlspecialchars($pageTitle ?? 'Scholarship Portal'); ?> - <?php echo SITE_NAME; ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>">
    
    <!-- Stylesheet -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>
    <!-- Header / Navigation -->
    <header class="header">
        <div class="container">
            <nav class="flex items-center justify-between py-4">
                <!-- Logo / Brand -->
                <a href="<?php echo SITE_URL; ?>/index.php" class="flex items-center gap-2 text-xl font-bold text-primary-700">
                    <span style="font-size: 1.5rem;">🎓</span>
                    <span><?php echo SITE_NAME; ?></span>
                </a>
                
                <!-- Navigation Links -->
                <div class="flex items-center gap-2">
                    <a href="<?php echo SITE_URL; ?>/index.php" 
                       class="nav-link <?php echo $currentPage === 'index' ? 'active' : ''; ?>">
                        Home
                    </a>
                    <a href="<?php echo SITE_URL; ?>/apply.php" 
                       class="nav-link <?php echo $currentPage === 'apply' ? 'active' : ''; ?>">
                        Apply Now
                    </a>
                    <a href="<?php echo SITE_URL; ?>/status.php" 
                       class="nav-link <?php echo $currentPage === 'status' ? 'active' : ''; ?>">
                        Check Status
                    </a>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- Flash Messages -->
    <div class="container mt-4">
        <?php echo displayFlashMessages(); ?>
    </div>
    
    <!-- Main Content -->
    <main>
