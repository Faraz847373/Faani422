<?php
/**
 * ============================================================
 * Helper Functions
 * ============================================================
 * 
 * Common utility functions used throughout the application.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

// ============================================================
// CSRF Protection Functions
// ============================================================

/**
 * Generate a CSRF token and store it in session
 * 
 * @return string The generated token
 */
function generateCSRFToken() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Get CSRF token input field HTML
 * 
 * @return string HTML hidden input field
 */
function csrfField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . htmlspecialchars($token) . '">';
}

/**
 * Validate CSRF token from POST request
 * 
 * @return bool True if valid, false otherwise
 */
function validateCSRFToken() {
    if (empty($_POST[CSRF_TOKEN_NAME]) || empty($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }
    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $_POST[CSRF_TOKEN_NAME]);
}

// ============================================================
// Input Sanitization Functions
// ============================================================

/**
 * Sanitize string input
 * 
 * @param string $input Raw input
 * @return string Sanitized input
 */
function sanitizeString($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitize email input
 * 
 * @param string $email Raw email
 * @return string|false Sanitized email or false if invalid
 */
function sanitizeEmail($email) {
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : false;
}

/**
 * Sanitize phone number (keep only digits and common separators)
 * 
 * @param string $phone Raw phone number
 * @return string Sanitized phone number
 */
function sanitizePhone($phone) {
    return preg_replace('/[^0-9+\-\s]/', '', trim($phone));
}

/**
 * Sanitize CNIC (Pakistani National ID format: XXXXX-XXXXXXX-X)
 * 
 * @param string $cnic Raw CNIC
 * @return string Sanitized CNIC
 */
function sanitizeCNIC($cnic) {
    // Remove all non-digits and dashes
    return preg_replace('/[^0-9\-]/', '', trim($cnic));
}

/**
 * Validate CNIC format
 * 
 * @param string $cnic CNIC to validate
 * @return bool True if valid format
 */
function validateCNIC($cnic) {
    // Format: XXXXX-XXXXXXX-X (with or without dashes)
    $cnic = preg_replace('/[^0-9]/', '', $cnic);
    return strlen($cnic) === 13;
}

/**
 * Format CNIC with dashes
 * 
 * @param string $cnic Raw CNIC
 * @return string Formatted CNIC
 */
function formatCNIC($cnic) {
    $cnic = preg_replace('/[^0-9]/', '', $cnic);
    if (strlen($cnic) === 13) {
        return substr($cnic, 0, 5) . '-' . substr($cnic, 5, 7) . '-' . substr($cnic, 12, 1);
    }
    return $cnic;
}

/**
 * Sanitize decimal/money input
 * 
 * @param mixed $amount Raw amount
 * @return float Sanitized amount
 */
function sanitizeAmount($amount) {
    return floatval(preg_replace('/[^0-9.]/', '', $amount));
}

// ============================================================
// File Upload Functions
// ============================================================

/**
 * Validate uploaded file
 * 
 * @param array $file $_FILES array element
 * @return array ['valid' => bool, 'error' => string|null]
 */
function validateUploadedFile($file) {
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds server size limit',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds form size limit',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'Upload stopped by extension'
        ];
        return [
            'valid' => false,
            'error' => $errors[$file['error']] ?? 'Unknown upload error'
        ];
    }
    
    // Check file size
    if ($file['size'] > MAX_FILE_SIZE) {
        return [
            'valid' => false,
            'error' => 'File size exceeds ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB limit'
        ];
    }
    
    // Check file extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS)) {
        return [
            'valid' => false,
            'error' => 'Invalid file type. Allowed: ' . implode(', ', ALLOWED_EXTENSIONS)
        ];
    }
    
    // Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, ALLOWED_MIME_TYPES)) {
        return [
            'valid' => false,
            'error' => 'Invalid file type detected'
        ];
    }
    
    return ['valid' => true, 'error' => null];
}

/**
 * Handle file upload and move to destination
 * 
 * @param array $file $_FILES array element
 * @param string $prefix Filename prefix
 * @return array ['success' => bool, 'path' => string|null, 'error' => string|null]
 */
function handleFileUpload($file, $prefix = 'doc') {
    // Validate file first
    $validation = validateUploadedFile($file);
    if (!$validation['valid']) {
        return [
            'success' => false,
            'path' => null,
            'error' => $validation['error']
        ];
    }
    
    // Create upload directory if it doesn't exist
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    
    // Generate unique filename
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = $prefix . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $destination = UPLOAD_DIR . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return [
            'success' => true,
            'path' => 'uploads/applications/' . $filename,
            'error' => null
        ];
    }
    
    return [
        'success' => false,
        'path' => null,
        'error' => 'Failed to save uploaded file'
    ];
}

// ============================================================
// Reference Number Functions
// ============================================================

/**
 * Generate unique application reference number
 * Format: SCH-YYYY-XXXXXX
 * 
 * @return string Reference number
 */
function generateReferenceNumber() {
    $year = date('Y');
    $random = str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
    $reference = "SCH-{$year}-{$random}";
    
    // Check if reference already exists (rare but possible)
    $db = db();
    $existing = $db->fetchOne(
        "SELECT id FROM applications WHERE reference_number = :ref",
        ['ref' => $reference]
    );
    
    // If exists, generate a new one recursively
    if ($existing) {
        return generateReferenceNumber();
    }
    
    return $reference;
}

// ============================================================
// Application Functions
// ============================================================

/**
 * Get application by reference number
 * 
 * @param string $reference Reference number
 * @return array|false Application data or false
 */
function getApplicationByReference($reference) {
    $db = db();
    return $db->fetchOne(
        "SELECT * FROM applications WHERE reference_number = :ref",
        ['ref' => sanitizeString($reference)]
    );
}

/**
 * Get application by CNIC
 * 
 * @param string $cnic CNIC number
 * @return array|false Application data or false
 */
function getApplicationByCNIC($cnic) {
    $cnic = preg_replace('/[^0-9]/', '', $cnic);
    $db = db();
    return $db->fetchOne(
        "SELECT * FROM applications WHERE REPLACE(REPLACE(cnic, '-', ''), ' ', '') = :cnic ORDER BY created_at DESC LIMIT 1",
        ['cnic' => $cnic]
    );
}

/**
 * Get status label from status code
 * 
 * @param string $status Status code
 * @return string Status label
 */
function getStatusLabel($status) {
    return STATUS_LABELS[$status] ?? 'Unknown';
}

/**
 * Get status color from status code
 * 
 * @param string $status Status code
 * @return string Hex color code
 */
function getStatusColor($status) {
    return STATUS_COLORS[$status] ?? '#6b7280';
}

// ============================================================
// Flash Message Functions
// ============================================================

/**
 * Set a flash message
 * 
 * @param string $type Message type (success, error, warning, info)
 * @param string $message Message content
 */
function setFlashMessage($type, $message) {
    $_SESSION['flash_messages'][] = [
        'type' => $type,
        'message' => $message
    ];
}

/**
 * Get and clear all flash messages
 * 
 * @return array Flash messages
 */
function getFlashMessages() {
    $messages = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $messages;
}

/**
 * Display flash messages as HTML
 * 
 * @return string HTML output
 */
function displayFlashMessages() {
    $messages = getFlashMessages();
    $html = '';
    
    $classes = [
        'success' => 'bg-green-100 border-green-500 text-green-700',
        'error' => 'bg-red-100 border-red-500 text-red-700',
        'warning' => 'bg-yellow-100 border-yellow-500 text-yellow-700',
        'info' => 'bg-blue-100 border-blue-500 text-blue-700'
    ];
    
    foreach ($messages as $msg) {
        $class = $classes[$msg['type']] ?? $classes['info'];
        $html .= '<div class="' . $class . ' border-l-4 p-4 mb-4" role="alert">';
        $html .= '<p>' . htmlspecialchars($msg['message']) . '</p>';
        $html .= '</div>';
    }
    
    return $html;
}

// ============================================================
// Utility Functions
// ============================================================

/**
 * Redirect to a URL
 * 
 * @param string $url URL to redirect to
 */
function redirect($url) {
    header("Location: {$url}");
    exit;
}

/**
 * Check if request is POST
 * 
 * @return bool
 */
function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Format date for display
 * 
 * @param string $date Date string
 * @param string $format Output format
 * @return string Formatted date
 */
function formatDate($date, $format = 'M d, Y h:i A') {
    return date($format, strtotime($date));
}

/**
 * Format currency for display
 * 
 * @param float $amount Amount
 * @param string $currency Currency symbol
 * @return string Formatted amount
 */
function formatCurrency($amount, $currency = 'PKR') {
    return $currency . ' ' . number_format($amount, 2);
}

/**
 * Get file extension icon class
 * 
 * @param string $filename Filename
 * @return string Icon class or emoji
 */
function getFileIcon($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $icons = [
        'pdf' => '📄',
        'jpg' => '🖼️',
        'jpeg' => '🖼️',
        'png' => '🖼️'
    ];
    return $icons[$ext] ?? '📎';
}

/**
 * Truncate text to specified length
 * 
 * @param string $text Text to truncate
 * @param int $length Maximum length
 * @param string $suffix Suffix to append
 * @return string Truncated text
 */
function truncate($text, $length = 100, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}
