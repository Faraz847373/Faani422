-- ============================================================
-- Scholarship Application Website - Database Schema
-- Compatible with MySQL 5.7+ / MariaDB 10.3+
-- ============================================================

-- Create database (run this manually or via command line)
-- CREATE DATABASE IF NOT EXISTS scholarship_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE scholarship_db;

-- ============================================================
-- Table: applications
-- Stores all student scholarship applications
-- ============================================================
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    
    -- Application Reference Number (unique identifier for tracking)
    reference_number VARCHAR(20) NOT NULL UNIQUE,
    
    -- Personal Information
    full_name VARCHAR(100) NOT NULL,
    father_name VARCHAR(100) NOT NULL,
    cnic VARCHAR(15) NOT NULL,  -- Format: XXXXX-XXXXXXX-X
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    
    -- Academic & Financial Information
    qualification VARCHAR(100) NOT NULL,
    monthly_income DECIMAL(12, 2) NOT NULL,
    address TEXT NOT NULL,
    
    -- Document Uploads (file paths)
    cnic_document VARCHAR(255) NOT NULL,
    educational_document VARCHAR(255) NOT NULL,
    
    -- Application Status
    -- Possible values: 'pending', 'under_review', 'approved', 'rejected'
    status ENUM('pending', 'under_review', 'approved', 'rejected') DEFAULT 'pending',
    
    -- Admin notes (internal use only)
    admin_notes TEXT,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Indexes for faster lookups
    INDEX idx_cnic (cnic),
    INDEX idx_reference (reference_number),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Table: admin_users
-- Stores administrator accounts for the admin panel
-- ============================================================
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    
    -- Admin credentials
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,  -- Stores bcrypt hashed password
    
    -- Admin profile
    full_name VARCHAR(100) NOT NULL,
    
    -- Account status
    is_active TINYINT(1) DEFAULT 1,
    
    -- Session management
    last_login TIMESTAMP NULL,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Table: application_status_history
-- Tracks status changes for audit purposes
-- ============================================================
CREATE TABLE IF NOT EXISTS application_status_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    
    -- Foreign key to applications table
    application_id INT NOT NULL,
    
    -- Status change details
    old_status ENUM('pending', 'under_review', 'approved', 'rejected'),
    new_status ENUM('pending', 'under_review', 'approved', 'rejected') NOT NULL,
    
    -- Who made the change
    changed_by INT,  -- References admin_users.id
    
    -- Notes about the change
    notes TEXT,
    
    -- Timestamp
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    
    INDEX idx_application (application_id),
    INDEX idx_changed_at (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Insert default admin user
-- Default credentials: admin / Admin@123
-- IMPORTANT: Change this password immediately after deployment!
-- ============================================================
INSERT INTO admin_users (username, email, password_hash, full_name) VALUES (
    'admin',
    'admin@example.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- Password: Admin@123
    'System Administrator'
);

-- ============================================================
-- Sample data for testing (optional - remove in production)
-- ============================================================
-- INSERT INTO applications (
--     reference_number, full_name, father_name, cnic, email, phone,
--     qualification, monthly_income, address, cnic_document, educational_document, status
-- ) VALUES (
--     'SCH-2024-000001',
--     'Ahmed Khan',
--     'Muhammad Khan',
--     '12345-1234567-1',
--     'ahmed@example.com',
--     '0300-1234567',
--     'Bachelor\'s Degree',
--     45000.00,
--     '123 Main Street, Karachi, Pakistan',
--     'uploads/applications/cnic_sample.pdf',
--     'uploads/applications/edu_sample.pdf',
--     'pending'
-- );
