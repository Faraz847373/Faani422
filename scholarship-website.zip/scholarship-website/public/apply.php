<?php
/**
 * ============================================================
 * Application Form Page
 * ============================================================
 * 
 * Scholarship application form with client-side and server-side
 * validation, file uploads, and CSRF protection.
 */

require_once __DIR__ . '/../includes/functions.php';

// Page metadata
$pageTitle = 'Apply for Scholarship';
$pageDescription = 'Submit your scholarship application online. Fill out the form and upload required documents.';

// Initialize form data and errors
$formData = [
    'full_name' => '',
    'father_name' => '',
    'cnic' => '',
    'email' => '',
    'phone' => '',
    'qualification' => '',
    'monthly_income' => '',
    'address' => ''
];
$errors = [];

// Handle form submission
if (isPost()) {
    // Validate CSRF token
    if (!validateCSRFToken()) {
        setFlashMessage('error', 'Invalid request. Please try again.');
        redirect('apply.php');
    }
    
    // Sanitize and validate input
    $formData['full_name'] = sanitizeString($_POST['full_name'] ?? '');
    $formData['father_name'] = sanitizeString($_POST['father_name'] ?? '');
    $formData['cnic'] = sanitizeCNIC($_POST['cnic'] ?? '');
    $formData['email'] = sanitizeEmail($_POST['email'] ?? '');
    $formData['phone'] = sanitizePhone($_POST['phone'] ?? '');
    $formData['qualification'] = sanitizeString($_POST['qualification'] ?? '');
    $formData['monthly_income'] = sanitizeAmount($_POST['monthly_income'] ?? '');
    $formData['address'] = sanitizeString($_POST['address'] ?? '');
    
    // Validation
    if (empty($formData['full_name'])) {
        $errors['full_name'] = 'Full name is required';
    } elseif (strlen($formData['full_name']) < 3) {
        $errors['full_name'] = 'Full name must be at least 3 characters';
    }
    
    if (empty($formData['father_name'])) {
        $errors['father_name'] = 'Father\'s name is required';
    }
    
    if (empty($formData['cnic'])) {
        $errors['cnic'] = 'CNIC is required';
    } elseif (!validateCNIC($formData['cnic'])) {
        $errors['cnic'] = 'Invalid CNIC format (must be 13 digits)';
    }
    
    if (!$formData['email']) {
        $errors['email'] = 'Valid email address is required';
    }
    
    if (empty($formData['phone'])) {
        $errors['phone'] = 'Phone number is required';
    }
    
    if (empty($formData['qualification'])) {
        $errors['qualification'] = 'Qualification is required';
    }
    
    if (empty($formData['monthly_income']) || $formData['monthly_income'] <= 0) {
        $errors['monthly_income'] = 'Valid monthly income is required';
    }
    
    if (empty($formData['address'])) {
        $errors['address'] = 'Address is required';
    }
    
    // Validate file uploads
    $cnicUpload = null;
    $eduUpload = null;
    
    if (empty($_FILES['cnic_document']['name'])) {
        $errors['cnic_document'] = 'CNIC document is required';
    } else {
        $cnicUpload = handleFileUpload($_FILES['cnic_document'], 'cnic');
        if (!$cnicUpload['success']) {
            $errors['cnic_document'] = $cnicUpload['error'];
        }
    }
    
    if (empty($_FILES['educational_document']['name'])) {
        $errors['educational_document'] = 'Educational document is required';
    } else {
        $eduUpload = handleFileUpload($_FILES['educational_document'], 'edu');
        if (!$eduUpload['success']) {
            $errors['educational_document'] = $eduUpload['error'];
        }
    }
    
    // If no errors, save to database
    if (empty($errors)) {
        try {
            $db = db();
            
            // Generate reference number
            $referenceNumber = generateReferenceNumber();
            
            // Format CNIC with dashes
            $formattedCNIC = formatCNIC($formData['cnic']);
            
            // Insert application
            $applicationId = $db->insert('applications', [
                'reference_number' => $referenceNumber,
                'full_name' => $formData['full_name'],
                'father_name' => $formData['father_name'],
                'cnic' => $formattedCNIC,
                'email' => $formData['email'],
                'phone' => $formData['phone'],
                'qualification' => $formData['qualification'],
                'monthly_income' => $formData['monthly_income'],
                'address' => $formData['address'],
                'cnic_document' => $cnicUpload['path'],
                'educational_document' => $eduUpload['path'],
                'status' => 'pending'
            ]);
            
            // Store reference number in session for success page
            $_SESSION['application_reference'] = $referenceNumber;
            $_SESSION['applicant_name'] = $formData['full_name'];
            
            // Redirect to success page
            redirect('success.php');
            
        } catch (Exception $e) {
            error_log("Application submission error: " . $e->getMessage());
            setFlashMessage('error', 'An error occurred while submitting your application. Please try again.');
        }
    }
}

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-primary-600 text-white py-8">
    <div class="container text-center">
        <h1 class="text-3xl font-bold mb-2">Scholarship Application Form</h1>
        <p class="opacity-90">Please fill out all required fields and upload the necessary documents.</p>
    </div>
</section>

<!-- Application Form -->
<section class="py-12">
    <div class="container">
        <div class="max-w-2xl mx-auto">
            
            <!-- Progress Indicator -->
            <div class="card mb-6">
                <div class="flex items-center justify-between text-sm">
                    <span class="text-primary-600 font-medium">📝 Fill Form</span>
                    <span class="text-gray-400">→</span>
                    <span class="text-gray-400">📤 Upload Documents</span>
                    <span class="text-gray-400">→</span>
                    <span class="text-gray-400">✅ Submit</span>
                </div>
            </div>
            
            <?php if (!empty($errors)): ?>
            <div class="alert alert-error mb-6">
                <strong>Please correct the following errors:</strong>
                <ul class="mt-2 ml-4" style="list-style: disc;">
                    <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <form id="applicationForm" 
                  action="apply.php" 
                  method="POST" 
                  enctype="multipart/form-data"
                  data-validate
                  class="card">
                
                <!-- CSRF Token -->
                <?php echo csrfField(); ?>
                
                <!-- Personal Information Section -->
                <div class="mb-8">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">
                        Personal Information
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Full Name -->
                        <div class="form-group">
                            <label for="full_name" class="form-label">
                                Full Name <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="full_name" 
                                   name="full_name" 
                                   class="form-input <?php echo isset($errors['full_name']) ? 'error' : ''; ?>"
                                   value="<?php echo htmlspecialchars($formData['full_name']); ?>"
                                   placeholder="Enter your full name"
                                   required
                                   minlength="3"
                                   maxlength="100">
                            <?php if (isset($errors['full_name'])): ?>
                            <span class="form-error"><?php echo $errors['full_name']; ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Father's Name -->
                        <div class="form-group">
                            <label for="father_name" class="form-label">
                                Father's Name <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="father_name" 
                                   name="father_name" 
                                   class="form-input <?php echo isset($errors['father_name']) ? 'error' : ''; ?>"
                                   value="<?php echo htmlspecialchars($formData['father_name']); ?>"
                                   placeholder="Enter father's name"
                                   required
                                   maxlength="100">
                            <?php if (isset($errors['father_name'])): ?>
                            <span class="form-error"><?php echo $errors['father_name']; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- CNIC -->
                    <div class="form-group">
                        <label for="cnic" class="form-label">
                            CNIC / National ID <span class="required">*</span>
                        </label>
                        <input type="text" 
                               id="cnic" 
                               name="cnic" 
                               class="form-input <?php echo isset($errors['cnic']) ? 'error' : ''; ?>"
                               value="<?php echo htmlspecialchars($formData['cnic']); ?>"
                               placeholder="XXXXX-XXXXXXX-X"
                               required
                               maxlength="15">
                        <span class="form-hint">Format: XXXXX-XXXXXXX-X (13 digits)</span>
                        <?php if (isset($errors['cnic'])): ?>
                        <span class="form-error"><?php echo $errors['cnic']; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Email -->
                        <div class="form-group">
                            <label for="email" class="form-label">
                                Email Address <span class="required">*</span>
                            </label>
                            <input type="email" 
                                   id="email" 
                                   name="email" 
                                   class="form-input <?php echo isset($errors['email']) ? 'error' : ''; ?>"
                                   value="<?php echo htmlspecialchars($formData['email']); ?>"
                                   placeholder="your.email@example.com"
                                   required>
                            <?php if (isset($errors['email'])): ?>
                            <span class="form-error"><?php echo $errors['email']; ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Phone -->
                        <div class="form-group">
                            <label for="phone" class="form-label">
                                Phone Number <span class="required">*</span>
                            </label>
                            <input type="tel" 
                                   id="phone" 
                                   name="phone" 
                                   class="form-input <?php echo isset($errors['phone']) ? 'error' : ''; ?>"
                                   value="<?php echo htmlspecialchars($formData['phone']); ?>"
                                   placeholder="03XX-XXXXXXX"
                                   required>
                            <?php if (isset($errors['phone'])): ?>
                            <span class="form-error"><?php echo $errors['phone']; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Academic & Financial Information -->
                <div class="mb-8">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">
                        Academic & Financial Information
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Qualification -->
                        <div class="form-group">
                            <label for="qualification" class="form-label">
                                Highest Qualification <span class="required">*</span>
                            </label>
                            <select id="qualification" 
                                    name="qualification" 
                                    class="form-select <?php echo isset($errors['qualification']) ? 'error' : ''; ?>"
                                    required>
                                <option value="">Select qualification</option>
                                <option value="Matriculation" <?php echo $formData['qualification'] === 'Matriculation' ? 'selected' : ''; ?>>Matriculation (10th)</option>
                                <option value="Intermediate" <?php echo $formData['qualification'] === 'Intermediate' ? 'selected' : ''; ?>>Intermediate (12th)</option>
                                <option value="Bachelor's Degree" <?php echo $formData['qualification'] === "Bachelor's Degree" ? 'selected' : ''; ?>>Bachelor's Degree</option>
                                <option value="Master's Degree" <?php echo $formData['qualification'] === "Master's Degree" ? 'selected' : ''; ?>>Master's Degree</option>
                                <option value="M.Phil" <?php echo $formData['qualification'] === 'M.Phil' ? 'selected' : ''; ?>>M.Phil</option>
                                <option value="PhD" <?php echo $formData['qualification'] === 'PhD' ? 'selected' : ''; ?>>PhD</option>
                                <option value="Other" <?php echo $formData['qualification'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                            <?php if (isset($errors['qualification'])): ?>
                            <span class="form-error"><?php echo $errors['qualification']; ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Monthly Income -->
                        <div class="form-group">
                            <label for="monthly_income" class="form-label">
                                Monthly Family Income (PKR) <span class="required">*</span>
                            </label>
                            <input type="number" 
                                   id="monthly_income" 
                                   name="monthly_income" 
                                   class="form-input <?php echo isset($errors['monthly_income']) ? 'error' : ''; ?>"
                                   value="<?php echo htmlspecialchars($formData['monthly_income']); ?>"
                                   placeholder="e.g., 50000"
                                   min="0"
                                   max="10000000"
                                   required>
                            <span class="form-hint">Enter total monthly household income</span>
                            <?php if (isset($errors['monthly_income'])): ?>
                            <span class="form-error"><?php echo $errors['monthly_income']; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Address -->
                    <div class="form-group">
                        <label for="address" class="form-label">
                            Complete Address <span class="required">*</span>
                        </label>
                        <textarea id="address" 
                                  name="address" 
                                  class="form-textarea <?php echo isset($errors['address']) ? 'error' : ''; ?>"
                                  placeholder="Enter your complete residential address"
                                  required
                                  rows="3"><?php echo htmlspecialchars($formData['address']); ?></textarea>
                        <?php if (isset($errors['address'])): ?>
                        <span class="form-error"><?php echo $errors['address']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Document Uploads -->
                <div class="mb-8">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">
                        Document Uploads
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- CNIC Document -->
                        <div class="form-group">
                            <label class="form-label">
                                CNIC Document <span class="required">*</span>
                            </label>
                            <div class="file-input-wrapper">
                                <input type="file" 
                                       id="cnic_document" 
                                       name="cnic_document" 
                                       class="file-input"
                                       accept=".pdf,.jpg,.jpeg,.png"
                                       required>
                                <label for="cnic_document" class="file-input-label">
                                    <div class="file-input-text">
                                        <div class="icon">🪪</div>
                                        <div class="font-medium">Upload CNIC</div>
                                        <div class="text-sm text-gray-500">PDF, JPG, PNG (max 5MB)</div>
                                    </div>
                                </label>
                                <div class="file-name"></div>
                            </div>
                            <?php if (isset($errors['cnic_document'])): ?>
                            <span class="form-error"><?php echo $errors['cnic_document']; ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Educational Document -->
                        <div class="form-group">
                            <label class="form-label">
                                Educational Document <span class="required">*</span>
                            </label>
                            <div class="file-input-wrapper">
                                <input type="file" 
                                       id="educational_document" 
                                       name="educational_document" 
                                       class="file-input"
                                       accept=".pdf,.jpg,.jpeg,.png"
                                       required>
                                <label for="educational_document" class="file-input-label">
                                    <div class="file-input-text">
                                        <div class="icon">📜</div>
                                        <div class="font-medium">Upload Certificate</div>
                                        <div class="text-sm text-gray-500">PDF, JPG, PNG (max 5MB)</div>
                                    </div>
                                </label>
                                <div class="file-name"></div>
                            </div>
                            <?php if (isset($errors['educational_document'])): ?>
                            <span class="form-error"><?php echo $errors['educational_document']; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Terms and Submit -->
                <div class="border-t pt-6">
                    <div class="form-group">
                        <label class="flex items-start gap-3 cursor-pointer">
                            <input type="checkbox" 
                                   name="terms" 
                                   required
                                   class="mt-1">
                            <span class="text-sm text-gray-600">
                                I hereby declare that all the information provided above is true and correct 
                                to the best of my knowledge. I understand that providing false information 
                                may result in disqualification from the scholarship program.
                                <span class="required">*</span>
                            </span>
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg btn-block">
                        Submit Application
                    </button>
                    
                    <p class="text-center text-sm text-gray-500 mt-4">
                        By submitting, you agree to our terms and conditions.
                    </p>
                </div>
            </form>
            
            <!-- Help Section -->
            <div class="mt-8 text-center">
                <p class="text-gray-600">
                    Need help? Contact us at 
                    <a href="mailto:<?php echo ADMIN_EMAIL; ?>" class="text-primary-600">
                        <?php echo ADMIN_EMAIL; ?>
                    </a>
                </p>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
require_once __DIR__ . '/../includes/footer.php';
?>
