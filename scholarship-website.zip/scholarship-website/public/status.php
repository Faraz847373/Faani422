<?php
/**
 * ============================================================
 * Application Status Check Page
 * ============================================================
 * 
 * Allows applicants to check their application status using
 * their CNIC or reference number.
 */

require_once __DIR__ . '/../includes/functions.php';

// Page metadata
$pageTitle = 'Check Application Status';
$pageDescription = 'Check the status of your scholarship application using your CNIC or reference number.';

// Initialize variables
$application = null;
$searchPerformed = false;
$searchValue = '';
$error = '';

// Handle status check
if (isPost() || isset($_GET['search'])) {
    $searchValue = sanitizeString($_POST['search'] ?? $_GET['search'] ?? '');
    $searchPerformed = true;
    
    if (empty($searchValue)) {
        $error = 'Please enter your CNIC or Reference Number';
    } else {
        // Try to find by reference number first
        if (strpos($searchValue, 'SCH-') === 0) {
            $application = getApplicationByReference($searchValue);
        } else {
            // Try CNIC
            $application = getApplicationByCNIC($searchValue);
        }
        
        if (!$application) {
            $error = 'No application found with the provided CNIC or Reference Number. Please check and try again.';
        }
    }
}

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-primary-600 text-white py-8">
    <div class="container text-center">
        <h1 class="text-3xl font-bold mb-2">Check Application Status</h1>
        <p class="opacity-90">Enter your CNIC or Reference Number to view your application status.</p>
    </div>
</section>

<!-- Status Check Section -->
<section class="py-12">
    <div class="container">
        <div class="max-w-xl mx-auto">
            
            <!-- Search Form -->
            <div class="card mb-8">
                <form id="statusForm" method="POST" action="status.php">
                    <div class="form-group mb-4">
                        <label for="search" class="form-label">
                            CNIC or Reference Number
                        </label>
                        <input type="text" 
                               id="search" 
                               name="search" 
                               class="form-input <?php echo $error ? 'error' : ''; ?>"
                               value="<?php echo htmlspecialchars($searchValue); ?>"
                               placeholder="Enter CNIC (XXXXX-XXXXXXX-X) or Reference (SCH-XXXX-XXXXXX)"
                               required>
                        <span class="form-hint">
                            Example: 12345-1234567-1 or SCH-<?php echo date('Y'); ?>-123456
                        </span>
                        <?php if ($error): ?>
                        <span class="form-error"><?php echo htmlspecialchars($error); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">
                        Check Status
                    </button>
                </form>
            </div>
            
            <?php if ($searchPerformed && $application): ?>
            <!-- Application Status Result -->
            <div class="card">
                <!-- Status Header -->
                <div class="status-card mb-6">
                    <div class="status-indicator <?php echo $application['status']; ?>">
                        <?php
                        $statusIcons = [
                            'pending' => '⏳',
                            'under_review' => '🔍',
                            'approved' => '✅',
                            'rejected' => '❌'
                        ];
                        echo $statusIcons[$application['status']] ?? '❓';
                        ?>
                    </div>
                    <h2 class="text-xl font-bold text-gray-800 mb-2">
                        <?php echo getStatusLabel($application['status']); ?>
                    </h2>
                    <span class="badge badge-<?php echo $application['status']; ?>">
                        <?php echo getStatusLabel($application['status']); ?>
                    </span>
                </div>
                
                <!-- Application Details -->
                <div class="border-t pt-6">
                    <h3 class="font-semibold text-gray-800 mb-4">Application Details</h3>
                    
                    <table class="w-full text-sm">
                        <tr class="border-b">
                            <td class="py-3 text-gray-500">Reference Number</td>
                            <td class="py-3 font-medium text-right font-mono">
                                <?php echo htmlspecialchars($application['reference_number']); ?>
                            </td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-3 text-gray-500">Applicant Name</td>
                            <td class="py-3 font-medium text-right">
                                <?php echo htmlspecialchars($application['full_name']); ?>
                            </td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-3 text-gray-500">CNIC</td>
                            <td class="py-3 font-medium text-right">
                                <?php echo htmlspecialchars($application['cnic']); ?>
                            </td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-3 text-gray-500">Qualification</td>
                            <td class="py-3 font-medium text-right">
                                <?php echo htmlspecialchars($application['qualification']); ?>
                            </td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-3 text-gray-500">Submitted On</td>
                            <td class="py-3 font-medium text-right">
                                <?php echo formatDate($application['created_at']); ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="py-3 text-gray-500">Last Updated</td>
                            <td class="py-3 font-medium text-right">
                                <?php echo formatDate($application['updated_at']); ?>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Status Message -->
                <div class="mt-6">
                    <?php if ($application['status'] === 'pending'): ?>
                    <div class="alert alert-warning">
                        <strong>Your application is pending review.</strong>
                        <p class="text-sm mt-1">
                            Our team will review your application soon. This typically takes 2-4 weeks.
                            Please check back later for updates.
                        </p>
                    </div>
                    <?php elseif ($application['status'] === 'under_review'): ?>
                    <div class="alert alert-info">
                        <strong>Your application is currently under review.</strong>
                        <p class="text-sm mt-1">
                            Our team is evaluating your application and documents. 
                            You will be notified once a decision is made.
                        </p>
                    </div>
                    <?php elseif ($application['status'] === 'approved'): ?>
                    <div class="alert alert-success">
                        <strong>Congratulations! Your application has been approved.</strong>
                        <p class="text-sm mt-1">
                            You will receive further instructions via email regarding the next steps 
                            and disbursement of the scholarship.
                        </p>
                    </div>
                    <?php elseif ($application['status'] === 'rejected'): ?>
                    <div class="alert alert-error">
                        <strong>We regret to inform you that your application was not approved.</strong>
                        <p class="text-sm mt-1">
                            <?php if (!empty($application['admin_notes'])): ?>
                            Reason: <?php echo htmlspecialchars($application['admin_notes']); ?>
                            <?php else: ?>
                            If you have questions, please contact us at <?php echo ADMIN_EMAIL; ?>.
                            <?php endif; ?>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Action Buttons -->
                <div class="mt-6 flex gap-4 justify-center">
                    <button onclick="window.print()" class="btn btn-secondary">
                        🖨️ Print Status
                    </button>
                    <a href="status.php" class="btn btn-outline">
                        Check Another
                    </a>
                </div>
            </div>
            <?php elseif ($searchPerformed && !$application): ?>
            <!-- No Results -->
            <div class="card text-center py-8">
                <div class="text-5xl mb-4">🔍</div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">No Application Found</h3>
                <p class="text-gray-600 mb-6">
                    We couldn't find any application matching your search criteria.
                </p>
                <div class="text-left max-w-md mx-auto">
                    <p class="text-sm text-gray-500 mb-2">Please check:</p>
                    <ul class="text-sm text-gray-600 ml-4" style="list-style: disc;">
                        <li>Your CNIC is entered correctly (13 digits)</li>
                        <li>Your reference number is entered exactly as provided</li>
                        <li>You have submitted an application</li>
                    </ul>
                </div>
                <div class="mt-6">
                    <a href="apply.php" class="btn btn-primary">
                        Submit New Application
                    </a>
                </div>
            </div>
            <?php else: ?>
            <!-- Initial State - Tips -->
            <div class="card">
                <h3 class="font-semibold text-gray-800 mb-4">How to check your status</h3>
                <div class="space-y-3">
                    <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-primary-600 text-xl">1️⃣</span>
                        <div>
                            <strong>Using Reference Number</strong>
                            <p class="text-sm text-gray-600">
                                Enter the reference number you received after submitting your application 
                                (e.g., SCH-<?php echo date('Y'); ?>-123456)
                            </p>
                        </div>
                    </div>
                    <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-primary-600 text-xl">2️⃣</span>
                        <div>
                            <strong>Using CNIC</strong>
                            <p class="text-sm text-gray-600">
                                Enter your 13-digit CNIC number with or without dashes 
                                (e.g., 12345-1234567-1)
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="mt-6 p-4 bg-primary-50 rounded-lg">
                    <p class="text-sm text-primary-700">
                        <strong>💡 Tip:</strong> If you haven't applied yet, 
                        <a href="apply.php" class="underline">click here to submit your application</a>.
                    </p>
                </div>
            </div>
            <?php endif; ?>
            
        </div>
    </div>
</section>

<style>
.space-y-3 > * + * {
    margin-top: 0.75rem;
}

@media print {
    form, .btn {
        display: none !important;
    }
}
</style>

<?php
// Include footer
require_once __DIR__ . '/../includes/footer.php';
?>
