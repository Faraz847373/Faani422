<?php
/**
 * ============================================================
 * Home Page
 * ============================================================
 * 
 * Landing page with scholarship information, eligibility
 * criteria, important dates, and call-to-action.
 */

require_once __DIR__ . '/../includes/functions.php';

// Page metadata
$pageTitle = 'Home';
$pageDescription = 'Apply for our scholarship program. Check eligibility criteria and submit your application online.';

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1>Scholarship Program <?php echo date('Y'); ?></h1>
        <p>
            Empowering deserving students to achieve their educational dreams. 
            Apply now for financial assistance to support your academic journey.
        </p>
        <div class="flex justify-center gap-4 flex-wrap">
            <a href="apply.php" class="btn btn-lg" style="background-color: white; color: var(--primary-700);">
                Apply Now
            </a>
            <a href="status.php" class="btn btn-lg btn-outline" style="border-color: white; color: white;">
                Check Status
            </a>
        </div>
    </div>
</section>

<!-- About the Scholarship -->
<section class="py-16">
    <div class="container">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">About the Scholarship</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Our scholarship program is designed to support talented and deserving students 
                who demonstrate academic excellence and financial need.
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Feature 1 -->
            <div class="card text-center">
                <div class="text-4xl mb-4">💰</div>
                <h3 class="text-xl font-semibold mb-2">Financial Support</h3>
                <p class="text-gray-600">
                    Receive financial assistance to cover tuition fees, books, 
                    and other educational expenses.
                </p>
            </div>
            
            <!-- Feature 2 -->
            <div class="card text-center">
                <div class="text-4xl mb-4">📚</div>
                <h3 class="text-xl font-semibold mb-2">Academic Excellence</h3>
                <p class="text-gray-600">
                    We support students who demonstrate strong academic performance 
                    and commitment to their studies.
                </p>
            </div>
            
            <!-- Feature 3 -->
            <div class="card text-center">
                <div class="text-4xl mb-4">🎯</div>
                <h3 class="text-xl font-semibold mb-2">Career Development</h3>
                <p class="text-gray-600">
                    Access mentorship programs and career guidance to help you 
                    achieve your professional goals.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Eligibility Criteria -->
<section class="py-16 bg-gray-100">
    <div class="container">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">Eligibility Criteria</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Please review the following criteria to determine if you qualify for our scholarship program.
            </p>
        </div>
        
        <div class="max-w-3xl mx-auto">
            <div class="card">
                <ul class="space-y-4">
                    <li class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-success text-xl">✓</span>
                        <div>
                            <strong>Citizenship:</strong> Must be a citizen of Pakistan with valid CNIC
                        </div>
                    </li>
                    <li class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-success text-xl">✓</span>
                        <div>
                            <strong>Academic Standing:</strong> Minimum 60% marks in previous examination
                        </div>
                    </li>
                    <li class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-success text-xl">✓</span>
                        <div>
                            <strong>Financial Need:</strong> Monthly family income below PKR 100,000
                        </div>
                    </li>
                    <li class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-success text-xl">✓</span>
                        <div>
                            <strong>Enrollment:</strong> Currently enrolled or seeking admission in a recognized institution
                        </div>
                    </li>
                    <li class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <span class="text-success text-xl">✓</span>
                        <div>
                            <strong>Age Limit:</strong> Between 16 and 30 years of age
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Important Dates -->
<section class="py-16">
    <div class="container">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">Important Dates</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Mark these important dates on your calendar to ensure you don't miss any deadlines.
            </p>
        </div>
        
        <div class="max-w-3xl mx-auto">
            <div class="card">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Event</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <strong>Application Opens</strong>
                                <br><small class="text-gray-500">Start submitting your applications</small>
                            </td>
                            <td>January 1, <?php echo date('Y'); ?></td>
                            <td><span class="badge badge-approved">Open</span></td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Application Deadline</strong>
                                <br><small class="text-gray-500">Last date to submit applications</small>
                            </td>
                            <td>March 31, <?php echo date('Y'); ?></td>
                            <td><span class="badge badge-pending">Upcoming</span></td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Document Verification</strong>
                                <br><small class="text-gray-500">Review of submitted documents</small>
                            </td>
                            <td>April 1-30, <?php echo date('Y'); ?></td>
                            <td><span class="badge badge-under_review">Scheduled</span></td>
                        </tr>
                        <tr>
                            <td>
                                <strong>Results Announcement</strong>
                                <br><small class="text-gray-500">Final selection results</small>
                            </td>
                            <td>May 15, <?php echo date('Y'); ?></td>
                            <td><span class="badge badge-under_review">Scheduled</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- Required Documents -->
<section class="py-16 bg-primary-50">
    <div class="container">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">Required Documents</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Please prepare the following documents before starting your application.
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div class="card flex items-start gap-4">
                <div class="text-3xl">🪪</div>
                <div>
                    <h4 class="font-semibold mb-1">CNIC / National ID</h4>
                    <p class="text-sm text-gray-600">
                        Scanned copy of your valid CNIC (front and back) in PDF, JPG, or PNG format.
                    </p>
                </div>
            </div>
            
            <div class="card flex items-start gap-4">
                <div class="text-3xl">📜</div>
                <div>
                    <h4 class="font-semibold mb-1">Educational Documents</h4>
                    <p class="text-sm text-gray-600">
                        Latest academic transcript, degree, or result card in PDF, JPG, or PNG format.
                    </p>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-8">
            <p class="text-sm text-gray-500 mb-4">
                Maximum file size: 5MB per document
            </p>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-16 bg-gradient-primary text-white text-center">
    <div class="container">
        <h2 class="text-3xl font-bold mb-4">Ready to Apply?</h2>
        <p class="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
            Don't miss this opportunity to secure financial support for your education. 
            Start your application today!
        </p>
        <a href="apply.php" class="btn btn-lg" style="background-color: white; color: var(--primary-700);">
            Start Application →
        </a>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-16">
    <div class="container">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
        </div>
        
        <div class="max-w-3xl mx-auto">
            <div class="card mb-4">
                <h4 class="font-semibold text-lg mb-2">How long does the application process take?</h4>
                <p class="text-gray-600">
                    The online application takes approximately 10-15 minutes to complete. 
                    Make sure you have all required documents ready before starting.
                </p>
            </div>
            
            <div class="card mb-4">
                <h4 class="font-semibold text-lg mb-2">Can I edit my application after submission?</h4>
                <p class="text-gray-600">
                    Once submitted, applications cannot be edited. Please review all information 
                    carefully before submitting.
                </p>
            </div>
            
            <div class="card mb-4">
                <h4 class="font-semibold text-lg mb-2">How will I know if my application is approved?</h4>
                <p class="text-gray-600">
                    You can check your application status anytime using your CNIC or reference number 
                    on our status page. You will also receive an email notification.
                </p>
            </div>
            
            <div class="card">
                <h4 class="font-semibold text-lg mb-2">What if I face technical issues during application?</h4>
                <p class="text-gray-600">
                    If you encounter any technical issues, please contact us at 
                    <a href="mailto:<?php echo ADMIN_EMAIL; ?>"><?php echo ADMIN_EMAIL; ?></a> 
                    with details of the problem.
                </p>
            </div>
        </div>
    </div>
</section>

<style>
/* Additional styles for spacing in lists */
.space-y-4 > * + * {
    margin-top: 1rem;
}
</style>

<?php
// Include footer
require_once __DIR__ . '/../includes/footer.php';
?>
