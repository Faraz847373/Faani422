<?php
/**
 * ============================================================
 * Application Success Page
 * ============================================================
 * 
 * Displays confirmation message and reference number after
 * successful application submission.
 */

require_once __DIR__ . '/../includes/functions.php';

// Check if user came from application form
if (empty($_SESSION['application_reference'])) {
    redirect('apply.php');
}

// Get reference number and applicant name from session
$referenceNumber = $_SESSION['application_reference'];
$applicantName = $_SESSION['applicant_name'] ?? 'Applicant';

// Clear session data (one-time display)
unset($_SESSION['application_reference']);
unset($_SESSION['applicant_name']);

// Page metadata
$pageTitle = 'Application Submitted';
$pageDescription = 'Your scholarship application has been successfully submitted.';

// Include header
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Success Section -->
<section class="py-16">
    <div class="container">
        <div class="max-w-xl mx-auto text-center">
            
            <!-- Success Card -->
            <div class="card">
                <!-- Success Icon -->
                <div class="success-icon">
                    ✓
                </div>
                
                <!-- Success Message -->
                <h1 class="text-2xl font-bold text-gray-800 mb-2">
                    Application Submitted Successfully!
                </h1>
                
                <p class="text-gray-600 mb-6">
                    Thank you, <strong><?php echo htmlspecialchars($applicantName); ?></strong>! 
                    Your scholarship application has been received and is now under review.
                </p>
                
                <!-- Reference Number Box -->
                <div class="bg-primary-50 border border-primary-200 rounded-lg p-6 mb-6">
                    <p class="text-sm text-gray-600 mb-2">Your Application Reference Number</p>
                    <p class="text-2xl font-bold text-primary-700 font-mono">
                        <?php echo htmlspecialchars($referenceNumber); ?>
                    </p>
                    <p class="text-xs text-gray-500 mt-2">
                        Please save this number for future reference
                    </p>
                </div>
                
                <!-- Important Notice -->
                <div class="alert alert-info text-left mb-6">
                    <strong>Important:</strong>
                    <ul class="mt-2 ml-4 text-sm" style="list-style: disc;">
                        <li>Save your reference number to check application status</li>
                        <li>You can also use your CNIC to track your application</li>
                        <li>Application review typically takes 2-4 weeks</li>
                        <li>You will be notified via email about any updates</li>
                    </ul>
                </div>
                
                <!-- What's Next Section -->
                <div class="text-left mb-6">
                    <h3 class="font-semibold text-gray-800 mb-3">What happens next?</h3>
                    <div class="space-y-3">
                        <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                            <span class="bg-primary-100 text-primary-700 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</span>
                            <div>
                                <strong>Document Verification</strong>
                                <p class="text-sm text-gray-600">Our team will verify your submitted documents</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                            <span class="bg-primary-100 text-primary-700 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</span>
                            <div>
                                <strong>Eligibility Assessment</strong>
                                <p class="text-sm text-gray-600">Your application will be evaluated against criteria</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                            <span class="bg-primary-100 text-primary-700 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</span>
                            <div>
                                <strong>Final Decision</strong>
                                <p class="text-sm text-gray-600">You'll receive notification about the outcome</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="status.php" class="btn btn-primary">
                        Check Application Status
                    </a>
                    <a href="index.php" class="btn btn-secondary">
                        Back to Home
                    </a>
                </div>
            </div>
            
            <!-- Print/Save Notice -->
            <div class="mt-6 text-sm text-gray-500">
                <p>
                    📄 We recommend printing or saving this page for your records.
                </p>
            </div>
            
        </div>
    </div>
</section>

<!-- Print Styles -->
<style>
@media print {
    .btn {
        display: none !important;
    }
    
    .card {
        box-shadow: none;
        border: 1px solid #e5e7eb;
    }
}

.space-y-3 > * + * {
    margin-top: 0.75rem;
}
</style>

<?php
// Include footer
require_once __DIR__ . '/../includes/footer.php';
?>
